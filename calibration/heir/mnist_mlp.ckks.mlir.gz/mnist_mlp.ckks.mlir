!ct_L0 = !lwe.lwe_ciphertext<plaintext_space = <ring = #ring_f64_1_x32768, encoding = #inverse_canonical_encoding>, ciphertext_space = #ciphertext_space_L0, key = #key, modulus_chain = #modulus_chain_L12_C0>
!ct_L1 = !lwe.lwe_ciphertext<plaintext_space = <ring = #ring_f64_1_x32768, encoding = #inverse_canonical_encoding>, ciphertext_space = #ciphertext_space_L1, key = #key, modulus_chain = #modulus_chain_L12_C1>
!ct_L1_1 = !lwe.lwe_ciphertext<plaintext_space = <ring = #ring_f64_1_x32768, encoding = #inverse_canonical_encoding1>, ciphertext_space = #ciphertext_space_L1, key = #key, modulus_chain = #modulus_chain_L12_C1>
!ct_L4 = !lwe.lwe_ciphertext<plaintext_space = <ring = #ring_f64_1_x32768, encoding = #inverse_canonical_encoding>, ciphertext_space = #ciphertext_space_L4, key = #key, modulus_chain = #modulus_chain_L12_C4>
!ct_L5 = !lwe.lwe_ciphertext<plaintext_space = <ring = #ring_f64_1_x32768, encoding = #inverse_canonical_encoding>, ciphertext_space = #ciphertext_space_L5, key = #key, modulus_chain = #modulus_chain_L12_C5>
!ct_L5_1 = !lwe.lwe_ciphertext<plaintext_space = <ring = #ring_f64_1_x32768, encoding = #inverse_canonical_encoding1>, ciphertext_space = #ciphertext_space_L5, key = #key, modulus_chain = #modulus_chain_L12_C5>
!ct_L6 = !lwe.lwe_ciphertext<plaintext_space = <ring = #ring_f64_1_x32768, encoding = #inverse_canonical_encoding>, ciphertext_space = #ciphertext_space_L6, key = #key, modulus_chain = #modulus_chain_L12_C6>
!ct_L6_1 = !lwe.lwe_ciphertext<plaintext_space = <ring = #ring_f64_1_x32768, encoding = #inverse_canonical_encoding1>, ciphertext_space = #ciphertext_space_L6, key = #key, modulus_chain = #modulus_chain_L12_C6>
module @jit_func attributes {backend.openfhe, ckks.schemeParam = #ckks.scheme_param<logN = 15, Q = [1073479681, 14155777, 20316161, 14942209, 20119553, 16121857, 20054017, 16384001, 19529729, 16515073, 19070977, 16580609, 17367041], P = [1152921504608747521, 1152921504614055937], logDefaultScale = 24>, jax.uses_shape_polymorphism = false, mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32, scheme.actual_slot_count = 16384 : i64, scheme.ckks, scheme.requested_slot_count = 4096 : i64} {
  func.func @mnist__preprocessed(%arg0: tensor<512x784xf32> {mhlo.sharding = "{replicated}"}, %arg1: tensor<512xf32> {mhlo.sharding = "{replicated}"}, %arg2: tensor<10x512xf32> {mhlo.sharding = "{replicated}"}, %arg3: tensor<10xf32> {mhlo.sharding = "{replicated}"}, %arg4: tensor<1x!ct_L6> {heir.kernel_info = {gap_factor = 1 : i64, result_shape = array<i64: 1, 784>}, tensor_ext.original_type = #tensor_ext.original_type<originalType = tensor<1x784xf32>, layout = #tensor_ext.layout<"{ [i0, i1] -> [ct, slot] : i0 = 0 and ct = 0 and (-i1 + slot) mod 1024 = 0 and 0 <= i1 <= 783 and 0 <= slot <= 4095 }">>}, %arg5: !preprocessing.storage<!pt>) -> tensor<1x!ct_L0> attributes {heir.interface = {func_name = "mnist", roles = ["client.preprocessed", "server.evaluate"]}} {
    %c512 = arith.constant 512 : index
    %c506 = arith.constant 506 : index
    %c483 = arith.constant 483 : index
    %c460 = arith.constant 460 : index
    %c437 = arith.constant 437 : index
    %c414 = arith.constant 414 : index
    %c391 = arith.constant 391 : index
    %c368 = arith.constant 368 : index
    %c345 = arith.constant 345 : index
    %c322 = arith.constant 322 : index
    %c299 = arith.constant 299 : index
    %c276 = arith.constant 276 : index
    %c256 = arith.constant 256 : index
    %c253 = arith.constant 253 : index
    %c230 = arith.constant 230 : index
    %c207 = arith.constant 207 : index
    %c184 = arith.constant 184 : index
    %c161 = arith.constant 161 : index
    %c138 = arith.constant 138 : index
    %c128 = arith.constant 128 : index
    %c115 = arith.constant 115 : index
    %c92 = arith.constant 92 : index
    %c69 = arith.constant 69 : index
    %c64 = arith.constant 64 : index
    %c46 = arith.constant 46 : index
    %c32 = arith.constant 32 : index
    %c23 = arith.constant 23 : index
    %c22 = arith.constant 22 : index
    %c21 = arith.constant 21 : index
    %c20 = arith.constant 20 : index
    %c19 = arith.constant 19 : index
    %c18 = arith.constant 18 : index
    %c17 = arith.constant 17 : index
    %c16 = arith.constant 16 : index
    %c15 = arith.constant 15 : index
    %c14 = arith.constant 14 : index
    %c13 = arith.constant 13 : index
    %c12 = arith.constant 12 : index
    %c11 = arith.constant 11 : index
    %c10 = arith.constant 10 : index
    %c9 = arith.constant 9 : index
    %c8 = arith.constant 8 : index
    %c7 = arith.constant 7 : index
    %c6 = arith.constant 6 : index
    %c5 = arith.constant 5 : index
    %c4 = arith.constant 4 : index
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %0 = call @_assign_layout_1479008790759535525(%arg0) : (tensor<512x784xf32>) -> tensor<512x4096xf32>
    %1 = call @_assign_layout_5160755363051149549(%arg1) : (tensor<512xf32>) -> tensor<1x4096xf32>
    %2 = call @_assign_layout_2874274348829223470(%arg2) : (tensor<10x512xf32>) -> tensor<16x4096xf32>
    %3 = call @_assign_layout_7911476497955777416(%arg3) : (tensor<10xf32>) -> tensor<1x4096xf32>
    %pt = preprocessing.load %arg5[] site 0<!pt> : <!pt>, !pt
    %extracted = tensor.extract %arg4[%c0] : tensor<1x!ct_L6>
    %ct = ckks.mul_plain %extracted, %pt : (!ct_L6, !pt) -> !ct_L6_1
    %ct_0 = ckks.rescale %ct <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_1 = ckks.rotate %extracted, %c1 : index : !ct_L6
    %pt_2 = preprocessing.load %arg5[] site 1<!pt> : <!pt>, !pt
    %ct_3 = ckks.mul_plain %ct_1, %pt_2 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_4 = ckks.rescale %ct_3 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_5 = ckks.rotate %extracted, %c2 : index : !ct_L6
    %pt_6 = preprocessing.load %arg5[] site 2<!pt> : <!pt>, !pt
    %ct_7 = ckks.mul_plain %ct_5, %pt_6 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_8 = ckks.rescale %ct_7 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_9 = ckks.rotate %extracted, %c3 : index : !ct_L6
    %pt_10 = preprocessing.load %arg5[] site 3<!pt> : <!pt>, !pt
    %ct_11 = ckks.mul_plain %ct_9, %pt_10 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_12 = ckks.rescale %ct_11 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_13 = ckks.rotate %extracted, %c4 : index : !ct_L6
    %pt_14 = preprocessing.load %arg5[] site 4<!pt> : <!pt>, !pt
    %ct_15 = ckks.mul_plain %ct_13, %pt_14 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_16 = ckks.rescale %ct_15 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_17 = ckks.rotate %extracted, %c5 : index : !ct_L6
    %pt_18 = preprocessing.load %arg5[] site 5<!pt> : <!pt>, !pt
    %ct_19 = ckks.mul_plain %ct_17, %pt_18 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_20 = ckks.rescale %ct_19 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_21 = ckks.rotate %extracted, %c6 : index : !ct_L6
    %pt_22 = preprocessing.load %arg5[] site 6<!pt> : <!pt>, !pt
    %ct_23 = ckks.mul_plain %ct_21, %pt_22 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_24 = ckks.rescale %ct_23 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_25 = ckks.rotate %extracted, %c7 : index : !ct_L6
    %pt_26 = preprocessing.load %arg5[] site 7<!pt> : <!pt>, !pt
    %ct_27 = ckks.mul_plain %ct_25, %pt_26 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_28 = ckks.rescale %ct_27 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_29 = ckks.rotate %extracted, %c8 : index : !ct_L6
    %pt_30 = preprocessing.load %arg5[] site 8<!pt> : <!pt>, !pt
    %ct_31 = ckks.mul_plain %ct_29, %pt_30 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_32 = ckks.rescale %ct_31 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_33 = ckks.rotate %extracted, %c9 : index : !ct_L6
    %pt_34 = preprocessing.load %arg5[] site 9<!pt> : <!pt>, !pt
    %ct_35 = ckks.mul_plain %ct_33, %pt_34 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_36 = ckks.rescale %ct_35 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_37 = ckks.rotate %extracted, %c10 : index : !ct_L6
    %pt_38 = preprocessing.load %arg5[] site 10<!pt> : <!pt>, !pt
    %ct_39 = ckks.mul_plain %ct_37, %pt_38 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_40 = ckks.rescale %ct_39 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_41 = ckks.rotate %extracted, %c11 : index : !ct_L6
    %pt_42 = preprocessing.load %arg5[] site 11<!pt> : <!pt>, !pt
    %ct_43 = ckks.mul_plain %ct_41, %pt_42 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_44 = ckks.rescale %ct_43 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_45 = ckks.rotate %extracted, %c12 : index : !ct_L6
    %pt_46 = preprocessing.load %arg5[] site 12<!pt> : <!pt>, !pt
    %ct_47 = ckks.mul_plain %ct_45, %pt_46 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_48 = ckks.rescale %ct_47 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_49 = ckks.rotate %extracted, %c13 : index : !ct_L6
    %pt_50 = preprocessing.load %arg5[] site 13<!pt> : <!pt>, !pt
    %ct_51 = ckks.mul_plain %ct_49, %pt_50 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_52 = ckks.rescale %ct_51 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_53 = ckks.rotate %extracted, %c14 : index : !ct_L6
    %pt_54 = preprocessing.load %arg5[] site 14<!pt> : <!pt>, !pt
    %ct_55 = ckks.mul_plain %ct_53, %pt_54 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_56 = ckks.rescale %ct_55 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_57 = ckks.rotate %extracted, %c15 : index : !ct_L6
    %pt_58 = preprocessing.load %arg5[] site 15<!pt> : <!pt>, !pt
    %ct_59 = ckks.mul_plain %ct_57, %pt_58 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_60 = ckks.rescale %ct_59 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_61 = ckks.rotate %extracted, %c16 : index : !ct_L6
    %pt_62 = preprocessing.load %arg5[] site 16<!pt> : <!pt>, !pt
    %ct_63 = ckks.mul_plain %ct_61, %pt_62 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_64 = ckks.rescale %ct_63 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_65 = ckks.rotate %extracted, %c17 : index : !ct_L6
    %pt_66 = preprocessing.load %arg5[] site 17<!pt> : <!pt>, !pt
    %ct_67 = ckks.mul_plain %ct_65, %pt_66 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_68 = ckks.rescale %ct_67 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_69 = ckks.rotate %extracted, %c18 : index : !ct_L6
    %pt_70 = preprocessing.load %arg5[] site 18<!pt> : <!pt>, !pt
    %ct_71 = ckks.mul_plain %ct_69, %pt_70 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_72 = ckks.rescale %ct_71 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_73 = ckks.rotate %extracted, %c19 : index : !ct_L6
    %pt_74 = preprocessing.load %arg5[] site 19<!pt> : <!pt>, !pt
    %ct_75 = ckks.mul_plain %ct_73, %pt_74 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_76 = ckks.rescale %ct_75 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_77 = ckks.rotate %extracted, %c20 : index : !ct_L6
    %pt_78 = preprocessing.load %arg5[] site 20<!pt> : <!pt>, !pt
    %ct_79 = ckks.mul_plain %ct_77, %pt_78 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_80 = ckks.rescale %ct_79 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_81 = ckks.rotate %extracted, %c21 : index : !ct_L6
    %pt_82 = preprocessing.load %arg5[] site 21<!pt> : <!pt>, !pt
    %ct_83 = ckks.mul_plain %ct_81, %pt_82 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_84 = ckks.rescale %ct_83 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_85 = ckks.rotate %extracted, %c22 : index : !ct_L6
    %pt_86 = preprocessing.load %arg5[] site 22<!pt> : <!pt>, !pt
    %ct_87 = ckks.mul_plain %ct_85, %pt_86 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_88 = ckks.rescale %ct_87 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_89 = preprocessing.load %arg5[] site 23<!pt> : <!pt>, !pt
    %ct_90 = ckks.mul_plain %extracted, %pt_89 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_91 = ckks.rescale %ct_90 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_92 = preprocessing.load %arg5[] site 24<!pt> : <!pt>, !pt
    %ct_93 = ckks.mul_plain %ct_1, %pt_92 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_94 = ckks.rescale %ct_93 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_95 = preprocessing.load %arg5[] site 25<!pt> : <!pt>, !pt
    %ct_96 = ckks.mul_plain %ct_5, %pt_95 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_97 = ckks.rescale %ct_96 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_98 = preprocessing.load %arg5[] site 26<!pt> : <!pt>, !pt
    %ct_99 = ckks.mul_plain %ct_9, %pt_98 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_100 = ckks.rescale %ct_99 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_101 = preprocessing.load %arg5[] site 27<!pt> : <!pt>, !pt
    %ct_102 = ckks.mul_plain %ct_13, %pt_101 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_103 = ckks.rescale %ct_102 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_104 = preprocessing.load %arg5[] site 28<!pt> : <!pt>, !pt
    %ct_105 = ckks.mul_plain %ct_17, %pt_104 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_106 = ckks.rescale %ct_105 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_107 = preprocessing.load %arg5[] site 29<!pt> : <!pt>, !pt
    %ct_108 = ckks.mul_plain %ct_21, %pt_107 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_109 = ckks.rescale %ct_108 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_110 = preprocessing.load %arg5[] site 30<!pt> : <!pt>, !pt
    %ct_111 = ckks.mul_plain %ct_25, %pt_110 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_112 = ckks.rescale %ct_111 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_113 = preprocessing.load %arg5[] site 31<!pt> : <!pt>, !pt
    %ct_114 = ckks.mul_plain %ct_29, %pt_113 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_115 = ckks.rescale %ct_114 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_116 = preprocessing.load %arg5[] site 32<!pt> : <!pt>, !pt
    %ct_117 = ckks.mul_plain %ct_33, %pt_116 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_118 = ckks.rescale %ct_117 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_119 = preprocessing.load %arg5[] site 33<!pt> : <!pt>, !pt
    %ct_120 = ckks.mul_plain %ct_37, %pt_119 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_121 = ckks.rescale %ct_120 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_122 = preprocessing.load %arg5[] site 34<!pt> : <!pt>, !pt
    %ct_123 = ckks.mul_plain %ct_41, %pt_122 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_124 = ckks.rescale %ct_123 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_125 = preprocessing.load %arg5[] site 35<!pt> : <!pt>, !pt
    %ct_126 = ckks.mul_plain %ct_45, %pt_125 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_127 = ckks.rescale %ct_126 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_128 = preprocessing.load %arg5[] site 36<!pt> : <!pt>, !pt
    %ct_129 = ckks.mul_plain %ct_49, %pt_128 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_130 = ckks.rescale %ct_129 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_131 = preprocessing.load %arg5[] site 37<!pt> : <!pt>, !pt
    %ct_132 = ckks.mul_plain %ct_53, %pt_131 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_133 = ckks.rescale %ct_132 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_134 = preprocessing.load %arg5[] site 38<!pt> : <!pt>, !pt
    %ct_135 = ckks.mul_plain %ct_57, %pt_134 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_136 = ckks.rescale %ct_135 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_137 = preprocessing.load %arg5[] site 39<!pt> : <!pt>, !pt
    %ct_138 = ckks.mul_plain %ct_61, %pt_137 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_139 = ckks.rescale %ct_138 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_140 = preprocessing.load %arg5[] site 40<!pt> : <!pt>, !pt
    %ct_141 = ckks.mul_plain %ct_65, %pt_140 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_142 = ckks.rescale %ct_141 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_143 = preprocessing.load %arg5[] site 41<!pt> : <!pt>, !pt
    %ct_144 = ckks.mul_plain %ct_69, %pt_143 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_145 = ckks.rescale %ct_144 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_146 = preprocessing.load %arg5[] site 42<!pt> : <!pt>, !pt
    %ct_147 = ckks.mul_plain %ct_73, %pt_146 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_148 = ckks.rescale %ct_147 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_149 = preprocessing.load %arg5[] site 43<!pt> : <!pt>, !pt
    %ct_150 = ckks.mul_plain %ct_77, %pt_149 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_151 = ckks.rescale %ct_150 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_152 = preprocessing.load %arg5[] site 44<!pt> : <!pt>, !pt
    %ct_153 = ckks.mul_plain %ct_81, %pt_152 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_154 = ckks.rescale %ct_153 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_155 = preprocessing.load %arg5[] site 45<!pt> : <!pt>, !pt
    %ct_156 = ckks.mul_plain %ct_85, %pt_155 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_157 = ckks.rescale %ct_156 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_158 = ckks.add %ct_91, %ct_94 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_159 = ckks.add %ct_97, %ct_100 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_160 = ckks.add %ct_159, %ct_103 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_161 = ckks.add %ct_158, %ct_160 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_162 = ckks.add %ct_106, %ct_109 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_163 = ckks.add %ct_162, %ct_112 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_164 = ckks.add %ct_115, %ct_118 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_165 = ckks.add %ct_164, %ct_121 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_166 = ckks.add %ct_163, %ct_165 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_167 = ckks.add %ct_161, %ct_166 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_168 = ckks.add %ct_124, %ct_127 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_169 = ckks.add %ct_168, %ct_130 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_170 = ckks.add %ct_133, %ct_136 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_171 = ckks.add %ct_170, %ct_139 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_172 = ckks.add %ct_169, %ct_171 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_173 = ckks.add %ct_142, %ct_145 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_174 = ckks.add %ct_173, %ct_148 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_175 = ckks.add %ct_151, %ct_154 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_176 = ckks.add %ct_175, %ct_157 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_177 = ckks.add %ct_174, %ct_176 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_178 = ckks.add %ct_172, %ct_177 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_179 = ckks.add %ct_167, %ct_178 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_180 = ckks.rotate %ct_179, %c23 : index : !ct_L5
    %pt_181 = preprocessing.load %arg5[] site 46<!pt> : <!pt>, !pt
    %ct_182 = ckks.mul_plain %extracted, %pt_181 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_183 = ckks.rescale %ct_182 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_184 = preprocessing.load %arg5[] site 47<!pt> : <!pt>, !pt
    %ct_185 = ckks.mul_plain %ct_1, %pt_184 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_186 = ckks.rescale %ct_185 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_187 = preprocessing.load %arg5[] site 48<!pt> : <!pt>, !pt
    %ct_188 = ckks.mul_plain %ct_5, %pt_187 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_189 = ckks.rescale %ct_188 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_190 = preprocessing.load %arg5[] site 49<!pt> : <!pt>, !pt
    %ct_191 = ckks.mul_plain %ct_9, %pt_190 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_192 = ckks.rescale %ct_191 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_193 = preprocessing.load %arg5[] site 50<!pt> : <!pt>, !pt
    %ct_194 = ckks.mul_plain %ct_13, %pt_193 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_195 = ckks.rescale %ct_194 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_196 = preprocessing.load %arg5[] site 51<!pt> : <!pt>, !pt
    %ct_197 = ckks.mul_plain %ct_17, %pt_196 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_198 = ckks.rescale %ct_197 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_199 = preprocessing.load %arg5[] site 52<!pt> : <!pt>, !pt
    %ct_200 = ckks.mul_plain %ct_21, %pt_199 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_201 = ckks.rescale %ct_200 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_202 = preprocessing.load %arg5[] site 53<!pt> : <!pt>, !pt
    %ct_203 = ckks.mul_plain %ct_25, %pt_202 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_204 = ckks.rescale %ct_203 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_205 = preprocessing.load %arg5[] site 54<!pt> : <!pt>, !pt
    %ct_206 = ckks.mul_plain %ct_29, %pt_205 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_207 = ckks.rescale %ct_206 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_208 = preprocessing.load %arg5[] site 55<!pt> : <!pt>, !pt
    %ct_209 = ckks.mul_plain %ct_33, %pt_208 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_210 = ckks.rescale %ct_209 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_211 = preprocessing.load %arg5[] site 56<!pt> : <!pt>, !pt
    %ct_212 = ckks.mul_plain %ct_37, %pt_211 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_213 = ckks.rescale %ct_212 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_214 = preprocessing.load %arg5[] site 57<!pt> : <!pt>, !pt
    %ct_215 = ckks.mul_plain %ct_41, %pt_214 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_216 = ckks.rescale %ct_215 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_217 = preprocessing.load %arg5[] site 58<!pt> : <!pt>, !pt
    %ct_218 = ckks.mul_plain %ct_45, %pt_217 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_219 = ckks.rescale %ct_218 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_220 = preprocessing.load %arg5[] site 59<!pt> : <!pt>, !pt
    %ct_221 = ckks.mul_plain %ct_49, %pt_220 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_222 = ckks.rescale %ct_221 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_223 = preprocessing.load %arg5[] site 60<!pt> : <!pt>, !pt
    %ct_224 = ckks.mul_plain %ct_53, %pt_223 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_225 = ckks.rescale %ct_224 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_226 = preprocessing.load %arg5[] site 61<!pt> : <!pt>, !pt
    %ct_227 = ckks.mul_plain %ct_57, %pt_226 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_228 = ckks.rescale %ct_227 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_229 = preprocessing.load %arg5[] site 62<!pt> : <!pt>, !pt
    %ct_230 = ckks.mul_plain %ct_61, %pt_229 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_231 = ckks.rescale %ct_230 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_232 = preprocessing.load %arg5[] site 63<!pt> : <!pt>, !pt
    %ct_233 = ckks.mul_plain %ct_65, %pt_232 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_234 = ckks.rescale %ct_233 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_235 = preprocessing.load %arg5[] site 64<!pt> : <!pt>, !pt
    %ct_236 = ckks.mul_plain %ct_69, %pt_235 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_237 = ckks.rescale %ct_236 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_238 = preprocessing.load %arg5[] site 65<!pt> : <!pt>, !pt
    %ct_239 = ckks.mul_plain %ct_73, %pt_238 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_240 = ckks.rescale %ct_239 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_241 = preprocessing.load %arg5[] site 66<!pt> : <!pt>, !pt
    %ct_242 = ckks.mul_plain %ct_77, %pt_241 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_243 = ckks.rescale %ct_242 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_244 = preprocessing.load %arg5[] site 67<!pt> : <!pt>, !pt
    %ct_245 = ckks.mul_plain %ct_81, %pt_244 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_246 = ckks.rescale %ct_245 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_247 = preprocessing.load %arg5[] site 68<!pt> : <!pt>, !pt
    %ct_248 = ckks.mul_plain %ct_85, %pt_247 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_249 = ckks.rescale %ct_248 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_250 = ckks.add %ct_183, %ct_186 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_251 = ckks.add %ct_189, %ct_192 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_252 = ckks.add %ct_251, %ct_195 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_253 = ckks.add %ct_250, %ct_252 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_254 = ckks.add %ct_198, %ct_201 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_255 = ckks.add %ct_254, %ct_204 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_256 = ckks.add %ct_207, %ct_210 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_257 = ckks.add %ct_256, %ct_213 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_258 = ckks.add %ct_255, %ct_257 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_259 = ckks.add %ct_253, %ct_258 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_260 = ckks.add %ct_216, %ct_219 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_261 = ckks.add %ct_260, %ct_222 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_262 = ckks.add %ct_225, %ct_228 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_263 = ckks.add %ct_262, %ct_231 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_264 = ckks.add %ct_261, %ct_263 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_265 = ckks.add %ct_234, %ct_237 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_266 = ckks.add %ct_265, %ct_240 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_267 = ckks.add %ct_243, %ct_246 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_268 = ckks.add %ct_267, %ct_249 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_269 = ckks.add %ct_266, %ct_268 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_270 = ckks.add %ct_264, %ct_269 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_271 = ckks.add %ct_259, %ct_270 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_272 = ckks.rotate %ct_271, %c46 : index : !ct_L5
    %pt_273 = preprocessing.load %arg5[] site 69<!pt> : <!pt>, !pt
    %ct_274 = ckks.mul_plain %extracted, %pt_273 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_275 = ckks.rescale %ct_274 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_276 = preprocessing.load %arg5[] site 70<!pt> : <!pt>, !pt
    %ct_277 = ckks.mul_plain %ct_1, %pt_276 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_278 = ckks.rescale %ct_277 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_279 = preprocessing.load %arg5[] site 71<!pt> : <!pt>, !pt
    %ct_280 = ckks.mul_plain %ct_5, %pt_279 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_281 = ckks.rescale %ct_280 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_282 = preprocessing.load %arg5[] site 72<!pt> : <!pt>, !pt
    %ct_283 = ckks.mul_plain %ct_9, %pt_282 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_284 = ckks.rescale %ct_283 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_285 = preprocessing.load %arg5[] site 73<!pt> : <!pt>, !pt
    %ct_286 = ckks.mul_plain %ct_13, %pt_285 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_287 = ckks.rescale %ct_286 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_288 = preprocessing.load %arg5[] site 74<!pt> : <!pt>, !pt
    %ct_289 = ckks.mul_plain %ct_17, %pt_288 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_290 = ckks.rescale %ct_289 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_291 = preprocessing.load %arg5[] site 75<!pt> : <!pt>, !pt
    %ct_292 = ckks.mul_plain %ct_21, %pt_291 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_293 = ckks.rescale %ct_292 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_294 = preprocessing.load %arg5[] site 76<!pt> : <!pt>, !pt
    %ct_295 = ckks.mul_plain %ct_25, %pt_294 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_296 = ckks.rescale %ct_295 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_297 = preprocessing.load %arg5[] site 77<!pt> : <!pt>, !pt
    %ct_298 = ckks.mul_plain %ct_29, %pt_297 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_299 = ckks.rescale %ct_298 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_300 = preprocessing.load %arg5[] site 78<!pt> : <!pt>, !pt
    %ct_301 = ckks.mul_plain %ct_33, %pt_300 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_302 = ckks.rescale %ct_301 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_303 = preprocessing.load %arg5[] site 79<!pt> : <!pt>, !pt
    %ct_304 = ckks.mul_plain %ct_37, %pt_303 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_305 = ckks.rescale %ct_304 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_306 = preprocessing.load %arg5[] site 80<!pt> : <!pt>, !pt
    %ct_307 = ckks.mul_plain %ct_41, %pt_306 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_308 = ckks.rescale %ct_307 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_309 = preprocessing.load %arg5[] site 81<!pt> : <!pt>, !pt
    %ct_310 = ckks.mul_plain %ct_45, %pt_309 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_311 = ckks.rescale %ct_310 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_312 = preprocessing.load %arg5[] site 82<!pt> : <!pt>, !pt
    %ct_313 = ckks.mul_plain %ct_49, %pt_312 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_314 = ckks.rescale %ct_313 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_315 = preprocessing.load %arg5[] site 83<!pt> : <!pt>, !pt
    %ct_316 = ckks.mul_plain %ct_53, %pt_315 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_317 = ckks.rescale %ct_316 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_318 = preprocessing.load %arg5[] site 84<!pt> : <!pt>, !pt
    %ct_319 = ckks.mul_plain %ct_57, %pt_318 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_320 = ckks.rescale %ct_319 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_321 = preprocessing.load %arg5[] site 85<!pt> : <!pt>, !pt
    %ct_322 = ckks.mul_plain %ct_61, %pt_321 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_323 = ckks.rescale %ct_322 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_324 = preprocessing.load %arg5[] site 86<!pt> : <!pt>, !pt
    %ct_325 = ckks.mul_plain %ct_65, %pt_324 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_326 = ckks.rescale %ct_325 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_327 = preprocessing.load %arg5[] site 87<!pt> : <!pt>, !pt
    %ct_328 = ckks.mul_plain %ct_69, %pt_327 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_329 = ckks.rescale %ct_328 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_330 = preprocessing.load %arg5[] site 88<!pt> : <!pt>, !pt
    %ct_331 = ckks.mul_plain %ct_73, %pt_330 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_332 = ckks.rescale %ct_331 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_333 = preprocessing.load %arg5[] site 89<!pt> : <!pt>, !pt
    %ct_334 = ckks.mul_plain %ct_77, %pt_333 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_335 = ckks.rescale %ct_334 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_336 = preprocessing.load %arg5[] site 90<!pt> : <!pt>, !pt
    %ct_337 = ckks.mul_plain %ct_81, %pt_336 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_338 = ckks.rescale %ct_337 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_339 = preprocessing.load %arg5[] site 91<!pt> : <!pt>, !pt
    %ct_340 = ckks.mul_plain %ct_85, %pt_339 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_341 = ckks.rescale %ct_340 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_342 = ckks.add %ct_275, %ct_278 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_343 = ckks.add %ct_281, %ct_284 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_344 = ckks.add %ct_343, %ct_287 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_345 = ckks.add %ct_342, %ct_344 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_346 = ckks.add %ct_290, %ct_293 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_347 = ckks.add %ct_346, %ct_296 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_348 = ckks.add %ct_299, %ct_302 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_349 = ckks.add %ct_348, %ct_305 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_350 = ckks.add %ct_347, %ct_349 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_351 = ckks.add %ct_345, %ct_350 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_352 = ckks.add %ct_308, %ct_311 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_353 = ckks.add %ct_352, %ct_314 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_354 = ckks.add %ct_317, %ct_320 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_355 = ckks.add %ct_354, %ct_323 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_356 = ckks.add %ct_353, %ct_355 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_357 = ckks.add %ct_326, %ct_329 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_358 = ckks.add %ct_357, %ct_332 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_359 = ckks.add %ct_335, %ct_338 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_360 = ckks.add %ct_359, %ct_341 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_361 = ckks.add %ct_358, %ct_360 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_362 = ckks.add %ct_356, %ct_361 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_363 = ckks.add %ct_351, %ct_362 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_364 = ckks.rotate %ct_363, %c69 : index : !ct_L5
    %pt_365 = preprocessing.load %arg5[] site 92<!pt> : <!pt>, !pt
    %ct_366 = ckks.mul_plain %extracted, %pt_365 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_367 = ckks.rescale %ct_366 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_368 = preprocessing.load %arg5[] site 93<!pt> : <!pt>, !pt
    %ct_369 = ckks.mul_plain %ct_1, %pt_368 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_370 = ckks.rescale %ct_369 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_371 = preprocessing.load %arg5[] site 94<!pt> : <!pt>, !pt
    %ct_372 = ckks.mul_plain %ct_5, %pt_371 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_373 = ckks.rescale %ct_372 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_374 = preprocessing.load %arg5[] site 95<!pt> : <!pt>, !pt
    %ct_375 = ckks.mul_plain %ct_9, %pt_374 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_376 = ckks.rescale %ct_375 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_377 = preprocessing.load %arg5[] site 96<!pt> : <!pt>, !pt
    %ct_378 = ckks.mul_plain %ct_13, %pt_377 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_379 = ckks.rescale %ct_378 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_380 = preprocessing.load %arg5[] site 97<!pt> : <!pt>, !pt
    %ct_381 = ckks.mul_plain %ct_17, %pt_380 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_382 = ckks.rescale %ct_381 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_383 = preprocessing.load %arg5[] site 98<!pt> : <!pt>, !pt
    %ct_384 = ckks.mul_plain %ct_21, %pt_383 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_385 = ckks.rescale %ct_384 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_386 = preprocessing.load %arg5[] site 99<!pt> : <!pt>, !pt
    %ct_387 = ckks.mul_plain %ct_25, %pt_386 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_388 = ckks.rescale %ct_387 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_389 = preprocessing.load %arg5[] site 100<!pt> : <!pt>, !pt
    %ct_390 = ckks.mul_plain %ct_29, %pt_389 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_391 = ckks.rescale %ct_390 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_392 = preprocessing.load %arg5[] site 101<!pt> : <!pt>, !pt
    %ct_393 = ckks.mul_plain %ct_33, %pt_392 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_394 = ckks.rescale %ct_393 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_395 = preprocessing.load %arg5[] site 102<!pt> : <!pt>, !pt
    %ct_396 = ckks.mul_plain %ct_37, %pt_395 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_397 = ckks.rescale %ct_396 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_398 = preprocessing.load %arg5[] site 103<!pt> : <!pt>, !pt
    %ct_399 = ckks.mul_plain %ct_41, %pt_398 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_400 = ckks.rescale %ct_399 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_401 = preprocessing.load %arg5[] site 104<!pt> : <!pt>, !pt
    %ct_402 = ckks.mul_plain %ct_45, %pt_401 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_403 = ckks.rescale %ct_402 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_404 = preprocessing.load %arg5[] site 105<!pt> : <!pt>, !pt
    %ct_405 = ckks.mul_plain %ct_49, %pt_404 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_406 = ckks.rescale %ct_405 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_407 = preprocessing.load %arg5[] site 106<!pt> : <!pt>, !pt
    %ct_408 = ckks.mul_plain %ct_53, %pt_407 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_409 = ckks.rescale %ct_408 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_410 = preprocessing.load %arg5[] site 107<!pt> : <!pt>, !pt
    %ct_411 = ckks.mul_plain %ct_57, %pt_410 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_412 = ckks.rescale %ct_411 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_413 = preprocessing.load %arg5[] site 108<!pt> : <!pt>, !pt
    %ct_414 = ckks.mul_plain %ct_61, %pt_413 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_415 = ckks.rescale %ct_414 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_416 = preprocessing.load %arg5[] site 109<!pt> : <!pt>, !pt
    %ct_417 = ckks.mul_plain %ct_65, %pt_416 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_418 = ckks.rescale %ct_417 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_419 = preprocessing.load %arg5[] site 110<!pt> : <!pt>, !pt
    %ct_420 = ckks.mul_plain %ct_69, %pt_419 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_421 = ckks.rescale %ct_420 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_422 = preprocessing.load %arg5[] site 111<!pt> : <!pt>, !pt
    %ct_423 = ckks.mul_plain %ct_73, %pt_422 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_424 = ckks.rescale %ct_423 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_425 = preprocessing.load %arg5[] site 112<!pt> : <!pt>, !pt
    %ct_426 = ckks.mul_plain %ct_77, %pt_425 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_427 = ckks.rescale %ct_426 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_428 = preprocessing.load %arg5[] site 113<!pt> : <!pt>, !pt
    %ct_429 = ckks.mul_plain %ct_81, %pt_428 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_430 = ckks.rescale %ct_429 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_431 = preprocessing.load %arg5[] site 114<!pt> : <!pt>, !pt
    %ct_432 = ckks.mul_plain %ct_85, %pt_431 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_433 = ckks.rescale %ct_432 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_434 = ckks.add %ct_367, %ct_370 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_435 = ckks.add %ct_373, %ct_376 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_436 = ckks.add %ct_435, %ct_379 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_437 = ckks.add %ct_434, %ct_436 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_438 = ckks.add %ct_382, %ct_385 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_439 = ckks.add %ct_438, %ct_388 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_440 = ckks.add %ct_391, %ct_394 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_441 = ckks.add %ct_440, %ct_397 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_442 = ckks.add %ct_439, %ct_441 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_443 = ckks.add %ct_437, %ct_442 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_444 = ckks.add %ct_400, %ct_403 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_445 = ckks.add %ct_444, %ct_406 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_446 = ckks.add %ct_409, %ct_412 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_447 = ckks.add %ct_446, %ct_415 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_448 = ckks.add %ct_445, %ct_447 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_449 = ckks.add %ct_418, %ct_421 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_450 = ckks.add %ct_449, %ct_424 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_451 = ckks.add %ct_427, %ct_430 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_452 = ckks.add %ct_451, %ct_433 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_453 = ckks.add %ct_450, %ct_452 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_454 = ckks.add %ct_448, %ct_453 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_455 = ckks.add %ct_443, %ct_454 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_456 = ckks.rotate %ct_455, %c92 : index : !ct_L5
    %pt_457 = preprocessing.load %arg5[] site 115<!pt> : <!pt>, !pt
    %ct_458 = ckks.mul_plain %extracted, %pt_457 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_459 = ckks.rescale %ct_458 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_460 = preprocessing.load %arg5[] site 116<!pt> : <!pt>, !pt
    %ct_461 = ckks.mul_plain %ct_1, %pt_460 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_462 = ckks.rescale %ct_461 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_463 = preprocessing.load %arg5[] site 117<!pt> : <!pt>, !pt
    %ct_464 = ckks.mul_plain %ct_5, %pt_463 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_465 = ckks.rescale %ct_464 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_466 = preprocessing.load %arg5[] site 118<!pt> : <!pt>, !pt
    %ct_467 = ckks.mul_plain %ct_9, %pt_466 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_468 = ckks.rescale %ct_467 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_469 = preprocessing.load %arg5[] site 119<!pt> : <!pt>, !pt
    %ct_470 = ckks.mul_plain %ct_13, %pt_469 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_471 = ckks.rescale %ct_470 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_472 = preprocessing.load %arg5[] site 120<!pt> : <!pt>, !pt
    %ct_473 = ckks.mul_plain %ct_17, %pt_472 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_474 = ckks.rescale %ct_473 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_475 = preprocessing.load %arg5[] site 121<!pt> : <!pt>, !pt
    %ct_476 = ckks.mul_plain %ct_21, %pt_475 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_477 = ckks.rescale %ct_476 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_478 = preprocessing.load %arg5[] site 122<!pt> : <!pt>, !pt
    %ct_479 = ckks.mul_plain %ct_25, %pt_478 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_480 = ckks.rescale %ct_479 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_481 = preprocessing.load %arg5[] site 123<!pt> : <!pt>, !pt
    %ct_482 = ckks.mul_plain %ct_29, %pt_481 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_483 = ckks.rescale %ct_482 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_484 = preprocessing.load %arg5[] site 124<!pt> : <!pt>, !pt
    %ct_485 = ckks.mul_plain %ct_33, %pt_484 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_486 = ckks.rescale %ct_485 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_487 = preprocessing.load %arg5[] site 125<!pt> : <!pt>, !pt
    %ct_488 = ckks.mul_plain %ct_37, %pt_487 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_489 = ckks.rescale %ct_488 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_490 = preprocessing.load %arg5[] site 126<!pt> : <!pt>, !pt
    %ct_491 = ckks.mul_plain %ct_41, %pt_490 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_492 = ckks.rescale %ct_491 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_493 = preprocessing.load %arg5[] site 127<!pt> : <!pt>, !pt
    %ct_494 = ckks.mul_plain %ct_45, %pt_493 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_495 = ckks.rescale %ct_494 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_496 = preprocessing.load %arg5[] site 128<!pt> : <!pt>, !pt
    %ct_497 = ckks.mul_plain %ct_49, %pt_496 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_498 = ckks.rescale %ct_497 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_499 = preprocessing.load %arg5[] site 129<!pt> : <!pt>, !pt
    %ct_500 = ckks.mul_plain %ct_53, %pt_499 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_501 = ckks.rescale %ct_500 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_502 = preprocessing.load %arg5[] site 130<!pt> : <!pt>, !pt
    %ct_503 = ckks.mul_plain %ct_57, %pt_502 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_504 = ckks.rescale %ct_503 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_505 = preprocessing.load %arg5[] site 131<!pt> : <!pt>, !pt
    %ct_506 = ckks.mul_plain %ct_61, %pt_505 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_507 = ckks.rescale %ct_506 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_508 = preprocessing.load %arg5[] site 132<!pt> : <!pt>, !pt
    %ct_509 = ckks.mul_plain %ct_65, %pt_508 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_510 = ckks.rescale %ct_509 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_511 = preprocessing.load %arg5[] site 133<!pt> : <!pt>, !pt
    %ct_512 = ckks.mul_plain %ct_69, %pt_511 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_513 = ckks.rescale %ct_512 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_514 = preprocessing.load %arg5[] site 134<!pt> : <!pt>, !pt
    %ct_515 = ckks.mul_plain %ct_73, %pt_514 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_516 = ckks.rescale %ct_515 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_517 = preprocessing.load %arg5[] site 135<!pt> : <!pt>, !pt
    %ct_518 = ckks.mul_plain %ct_77, %pt_517 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_519 = ckks.rescale %ct_518 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_520 = preprocessing.load %arg5[] site 136<!pt> : <!pt>, !pt
    %ct_521 = ckks.mul_plain %ct_81, %pt_520 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_522 = ckks.rescale %ct_521 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_523 = preprocessing.load %arg5[] site 137<!pt> : <!pt>, !pt
    %ct_524 = ckks.mul_plain %ct_85, %pt_523 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_525 = ckks.rescale %ct_524 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_526 = ckks.add %ct_459, %ct_462 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_527 = ckks.add %ct_465, %ct_468 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_528 = ckks.add %ct_527, %ct_471 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_529 = ckks.add %ct_526, %ct_528 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_530 = ckks.add %ct_474, %ct_477 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_531 = ckks.add %ct_530, %ct_480 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_532 = ckks.add %ct_483, %ct_486 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_533 = ckks.add %ct_532, %ct_489 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_534 = ckks.add %ct_531, %ct_533 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_535 = ckks.add %ct_529, %ct_534 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_536 = ckks.add %ct_492, %ct_495 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_537 = ckks.add %ct_536, %ct_498 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_538 = ckks.add %ct_501, %ct_504 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_539 = ckks.add %ct_538, %ct_507 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_540 = ckks.add %ct_537, %ct_539 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_541 = ckks.add %ct_510, %ct_513 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_542 = ckks.add %ct_541, %ct_516 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_543 = ckks.add %ct_519, %ct_522 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_544 = ckks.add %ct_543, %ct_525 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_545 = ckks.add %ct_542, %ct_544 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_546 = ckks.add %ct_540, %ct_545 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_547 = ckks.add %ct_535, %ct_546 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_548 = ckks.rotate %ct_547, %c115 : index : !ct_L5
    %pt_549 = preprocessing.load %arg5[] site 138<!pt> : <!pt>, !pt
    %ct_550 = ckks.mul_plain %extracted, %pt_549 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_551 = ckks.rescale %ct_550 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_552 = preprocessing.load %arg5[] site 139<!pt> : <!pt>, !pt
    %ct_553 = ckks.mul_plain %ct_1, %pt_552 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_554 = ckks.rescale %ct_553 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_555 = preprocessing.load %arg5[] site 140<!pt> : <!pt>, !pt
    %ct_556 = ckks.mul_plain %ct_5, %pt_555 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_557 = ckks.rescale %ct_556 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_558 = preprocessing.load %arg5[] site 141<!pt> : <!pt>, !pt
    %ct_559 = ckks.mul_plain %ct_9, %pt_558 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_560 = ckks.rescale %ct_559 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_561 = preprocessing.load %arg5[] site 142<!pt> : <!pt>, !pt
    %ct_562 = ckks.mul_plain %ct_13, %pt_561 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_563 = ckks.rescale %ct_562 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_564 = preprocessing.load %arg5[] site 143<!pt> : <!pt>, !pt
    %ct_565 = ckks.mul_plain %ct_17, %pt_564 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_566 = ckks.rescale %ct_565 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_567 = preprocessing.load %arg5[] site 144<!pt> : <!pt>, !pt
    %ct_568 = ckks.mul_plain %ct_21, %pt_567 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_569 = ckks.rescale %ct_568 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_570 = preprocessing.load %arg5[] site 145<!pt> : <!pt>, !pt
    %ct_571 = ckks.mul_plain %ct_25, %pt_570 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_572 = ckks.rescale %ct_571 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_573 = preprocessing.load %arg5[] site 146<!pt> : <!pt>, !pt
    %ct_574 = ckks.mul_plain %ct_29, %pt_573 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_575 = ckks.rescale %ct_574 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_576 = preprocessing.load %arg5[] site 147<!pt> : <!pt>, !pt
    %ct_577 = ckks.mul_plain %ct_33, %pt_576 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_578 = ckks.rescale %ct_577 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_579 = preprocessing.load %arg5[] site 148<!pt> : <!pt>, !pt
    %ct_580 = ckks.mul_plain %ct_37, %pt_579 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_581 = ckks.rescale %ct_580 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_582 = preprocessing.load %arg5[] site 149<!pt> : <!pt>, !pt
    %ct_583 = ckks.mul_plain %ct_41, %pt_582 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_584 = ckks.rescale %ct_583 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_585 = preprocessing.load %arg5[] site 150<!pt> : <!pt>, !pt
    %ct_586 = ckks.mul_plain %ct_45, %pt_585 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_587 = ckks.rescale %ct_586 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_588 = preprocessing.load %arg5[] site 151<!pt> : <!pt>, !pt
    %ct_589 = ckks.mul_plain %ct_49, %pt_588 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_590 = ckks.rescale %ct_589 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_591 = preprocessing.load %arg5[] site 152<!pt> : <!pt>, !pt
    %ct_592 = ckks.mul_plain %ct_53, %pt_591 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_593 = ckks.rescale %ct_592 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_594 = preprocessing.load %arg5[] site 153<!pt> : <!pt>, !pt
    %ct_595 = ckks.mul_plain %ct_57, %pt_594 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_596 = ckks.rescale %ct_595 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_597 = preprocessing.load %arg5[] site 154<!pt> : <!pt>, !pt
    %ct_598 = ckks.mul_plain %ct_61, %pt_597 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_599 = ckks.rescale %ct_598 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_600 = preprocessing.load %arg5[] site 155<!pt> : <!pt>, !pt
    %ct_601 = ckks.mul_plain %ct_65, %pt_600 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_602 = ckks.rescale %ct_601 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_603 = preprocessing.load %arg5[] site 156<!pt> : <!pt>, !pt
    %ct_604 = ckks.mul_plain %ct_69, %pt_603 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_605 = ckks.rescale %ct_604 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_606 = preprocessing.load %arg5[] site 157<!pt> : <!pt>, !pt
    %ct_607 = ckks.mul_plain %ct_73, %pt_606 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_608 = ckks.rescale %ct_607 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_609 = preprocessing.load %arg5[] site 158<!pt> : <!pt>, !pt
    %ct_610 = ckks.mul_plain %ct_77, %pt_609 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_611 = ckks.rescale %ct_610 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_612 = preprocessing.load %arg5[] site 159<!pt> : <!pt>, !pt
    %ct_613 = ckks.mul_plain %ct_81, %pt_612 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_614 = ckks.rescale %ct_613 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_615 = preprocessing.load %arg5[] site 160<!pt> : <!pt>, !pt
    %ct_616 = ckks.mul_plain %ct_85, %pt_615 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_617 = ckks.rescale %ct_616 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_618 = ckks.add %ct_551, %ct_554 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_619 = ckks.add %ct_557, %ct_560 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_620 = ckks.add %ct_619, %ct_563 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_621 = ckks.add %ct_618, %ct_620 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_622 = ckks.add %ct_566, %ct_569 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_623 = ckks.add %ct_622, %ct_572 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_624 = ckks.add %ct_575, %ct_578 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_625 = ckks.add %ct_624, %ct_581 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_626 = ckks.add %ct_623, %ct_625 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_627 = ckks.add %ct_621, %ct_626 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_628 = ckks.add %ct_584, %ct_587 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_629 = ckks.add %ct_628, %ct_590 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_630 = ckks.add %ct_593, %ct_596 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_631 = ckks.add %ct_630, %ct_599 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_632 = ckks.add %ct_629, %ct_631 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_633 = ckks.add %ct_602, %ct_605 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_634 = ckks.add %ct_633, %ct_608 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_635 = ckks.add %ct_611, %ct_614 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_636 = ckks.add %ct_635, %ct_617 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_637 = ckks.add %ct_634, %ct_636 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_638 = ckks.add %ct_632, %ct_637 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_639 = ckks.add %ct_627, %ct_638 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_640 = ckks.rotate %ct_639, %c138 : index : !ct_L5
    %pt_641 = preprocessing.load %arg5[] site 161<!pt> : <!pt>, !pt
    %ct_642 = ckks.mul_plain %extracted, %pt_641 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_643 = ckks.rescale %ct_642 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_644 = preprocessing.load %arg5[] site 162<!pt> : <!pt>, !pt
    %ct_645 = ckks.mul_plain %ct_1, %pt_644 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_646 = ckks.rescale %ct_645 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_647 = preprocessing.load %arg5[] site 163<!pt> : <!pt>, !pt
    %ct_648 = ckks.mul_plain %ct_5, %pt_647 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_649 = ckks.rescale %ct_648 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_650 = preprocessing.load %arg5[] site 164<!pt> : <!pt>, !pt
    %ct_651 = ckks.mul_plain %ct_9, %pt_650 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_652 = ckks.rescale %ct_651 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_653 = preprocessing.load %arg5[] site 165<!pt> : <!pt>, !pt
    %ct_654 = ckks.mul_plain %ct_13, %pt_653 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_655 = ckks.rescale %ct_654 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_656 = preprocessing.load %arg5[] site 166<!pt> : <!pt>, !pt
    %ct_657 = ckks.mul_plain %ct_17, %pt_656 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_658 = ckks.rescale %ct_657 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_659 = preprocessing.load %arg5[] site 167<!pt> : <!pt>, !pt
    %ct_660 = ckks.mul_plain %ct_21, %pt_659 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_661 = ckks.rescale %ct_660 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_662 = preprocessing.load %arg5[] site 168<!pt> : <!pt>, !pt
    %ct_663 = ckks.mul_plain %ct_25, %pt_662 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_664 = ckks.rescale %ct_663 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_665 = preprocessing.load %arg5[] site 169<!pt> : <!pt>, !pt
    %ct_666 = ckks.mul_plain %ct_29, %pt_665 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_667 = ckks.rescale %ct_666 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_668 = preprocessing.load %arg5[] site 170<!pt> : <!pt>, !pt
    %ct_669 = ckks.mul_plain %ct_33, %pt_668 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_670 = ckks.rescale %ct_669 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_671 = preprocessing.load %arg5[] site 171<!pt> : <!pt>, !pt
    %ct_672 = ckks.mul_plain %ct_37, %pt_671 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_673 = ckks.rescale %ct_672 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_674 = preprocessing.load %arg5[] site 172<!pt> : <!pt>, !pt
    %ct_675 = ckks.mul_plain %ct_41, %pt_674 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_676 = ckks.rescale %ct_675 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_677 = preprocessing.load %arg5[] site 173<!pt> : <!pt>, !pt
    %ct_678 = ckks.mul_plain %ct_45, %pt_677 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_679 = ckks.rescale %ct_678 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_680 = preprocessing.load %arg5[] site 174<!pt> : <!pt>, !pt
    %ct_681 = ckks.mul_plain %ct_49, %pt_680 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_682 = ckks.rescale %ct_681 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_683 = preprocessing.load %arg5[] site 175<!pt> : <!pt>, !pt
    %ct_684 = ckks.mul_plain %ct_53, %pt_683 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_685 = ckks.rescale %ct_684 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_686 = preprocessing.load %arg5[] site 176<!pt> : <!pt>, !pt
    %ct_687 = ckks.mul_plain %ct_57, %pt_686 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_688 = ckks.rescale %ct_687 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_689 = preprocessing.load %arg5[] site 177<!pt> : <!pt>, !pt
    %ct_690 = ckks.mul_plain %ct_61, %pt_689 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_691 = ckks.rescale %ct_690 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_692 = preprocessing.load %arg5[] site 178<!pt> : <!pt>, !pt
    %ct_693 = ckks.mul_plain %ct_65, %pt_692 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_694 = ckks.rescale %ct_693 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_695 = preprocessing.load %arg5[] site 179<!pt> : <!pt>, !pt
    %ct_696 = ckks.mul_plain %ct_69, %pt_695 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_697 = ckks.rescale %ct_696 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_698 = preprocessing.load %arg5[] site 180<!pt> : <!pt>, !pt
    %ct_699 = ckks.mul_plain %ct_73, %pt_698 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_700 = ckks.rescale %ct_699 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_701 = preprocessing.load %arg5[] site 181<!pt> : <!pt>, !pt
    %ct_702 = ckks.mul_plain %ct_77, %pt_701 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_703 = ckks.rescale %ct_702 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_704 = preprocessing.load %arg5[] site 182<!pt> : <!pt>, !pt
    %ct_705 = ckks.mul_plain %ct_81, %pt_704 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_706 = ckks.rescale %ct_705 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_707 = preprocessing.load %arg5[] site 183<!pt> : <!pt>, !pt
    %ct_708 = ckks.mul_plain %ct_85, %pt_707 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_709 = ckks.rescale %ct_708 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_710 = ckks.add %ct_643, %ct_646 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_711 = ckks.add %ct_649, %ct_652 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_712 = ckks.add %ct_711, %ct_655 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_713 = ckks.add %ct_710, %ct_712 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_714 = ckks.add %ct_658, %ct_661 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_715 = ckks.add %ct_714, %ct_664 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_716 = ckks.add %ct_667, %ct_670 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_717 = ckks.add %ct_716, %ct_673 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_718 = ckks.add %ct_715, %ct_717 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_719 = ckks.add %ct_713, %ct_718 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_720 = ckks.add %ct_676, %ct_679 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_721 = ckks.add %ct_720, %ct_682 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_722 = ckks.add %ct_685, %ct_688 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_723 = ckks.add %ct_722, %ct_691 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_724 = ckks.add %ct_721, %ct_723 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_725 = ckks.add %ct_694, %ct_697 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_726 = ckks.add %ct_725, %ct_700 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_727 = ckks.add %ct_703, %ct_706 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_728 = ckks.add %ct_727, %ct_709 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_729 = ckks.add %ct_726, %ct_728 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_730 = ckks.add %ct_724, %ct_729 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_731 = ckks.add %ct_719, %ct_730 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_732 = ckks.rotate %ct_731, %c161 : index : !ct_L5
    %pt_733 = preprocessing.load %arg5[] site 184<!pt> : <!pt>, !pt
    %ct_734 = ckks.mul_plain %extracted, %pt_733 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_735 = ckks.rescale %ct_734 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_736 = preprocessing.load %arg5[] site 185<!pt> : <!pt>, !pt
    %ct_737 = ckks.mul_plain %ct_1, %pt_736 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_738 = ckks.rescale %ct_737 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_739 = preprocessing.load %arg5[] site 186<!pt> : <!pt>, !pt
    %ct_740 = ckks.mul_plain %ct_5, %pt_739 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_741 = ckks.rescale %ct_740 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_742 = preprocessing.load %arg5[] site 187<!pt> : <!pt>, !pt
    %ct_743 = ckks.mul_plain %ct_9, %pt_742 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_744 = ckks.rescale %ct_743 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_745 = preprocessing.load %arg5[] site 188<!pt> : <!pt>, !pt
    %ct_746 = ckks.mul_plain %ct_13, %pt_745 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_747 = ckks.rescale %ct_746 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_748 = preprocessing.load %arg5[] site 189<!pt> : <!pt>, !pt
    %ct_749 = ckks.mul_plain %ct_17, %pt_748 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_750 = ckks.rescale %ct_749 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_751 = preprocessing.load %arg5[] site 190<!pt> : <!pt>, !pt
    %ct_752 = ckks.mul_plain %ct_21, %pt_751 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_753 = ckks.rescale %ct_752 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_754 = preprocessing.load %arg5[] site 191<!pt> : <!pt>, !pt
    %ct_755 = ckks.mul_plain %ct_25, %pt_754 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_756 = ckks.rescale %ct_755 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_757 = preprocessing.load %arg5[] site 192<!pt> : <!pt>, !pt
    %ct_758 = ckks.mul_plain %ct_29, %pt_757 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_759 = ckks.rescale %ct_758 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_760 = preprocessing.load %arg5[] site 193<!pt> : <!pt>, !pt
    %ct_761 = ckks.mul_plain %ct_33, %pt_760 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_762 = ckks.rescale %ct_761 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_763 = preprocessing.load %arg5[] site 194<!pt> : <!pt>, !pt
    %ct_764 = ckks.mul_plain %ct_37, %pt_763 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_765 = ckks.rescale %ct_764 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_766 = preprocessing.load %arg5[] site 195<!pt> : <!pt>, !pt
    %ct_767 = ckks.mul_plain %ct_41, %pt_766 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_768 = ckks.rescale %ct_767 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_769 = preprocessing.load %arg5[] site 196<!pt> : <!pt>, !pt
    %ct_770 = ckks.mul_plain %ct_45, %pt_769 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_771 = ckks.rescale %ct_770 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_772 = preprocessing.load %arg5[] site 197<!pt> : <!pt>, !pt
    %ct_773 = ckks.mul_plain %ct_49, %pt_772 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_774 = ckks.rescale %ct_773 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_775 = preprocessing.load %arg5[] site 198<!pt> : <!pt>, !pt
    %ct_776 = ckks.mul_plain %ct_53, %pt_775 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_777 = ckks.rescale %ct_776 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_778 = preprocessing.load %arg5[] site 199<!pt> : <!pt>, !pt
    %ct_779 = ckks.mul_plain %ct_57, %pt_778 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_780 = ckks.rescale %ct_779 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_781 = preprocessing.load %arg5[] site 200<!pt> : <!pt>, !pt
    %ct_782 = ckks.mul_plain %ct_61, %pt_781 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_783 = ckks.rescale %ct_782 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_784 = preprocessing.load %arg5[] site 201<!pt> : <!pt>, !pt
    %ct_785 = ckks.mul_plain %ct_65, %pt_784 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_786 = ckks.rescale %ct_785 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_787 = preprocessing.load %arg5[] site 202<!pt> : <!pt>, !pt
    %ct_788 = ckks.mul_plain %ct_69, %pt_787 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_789 = ckks.rescale %ct_788 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_790 = preprocessing.load %arg5[] site 203<!pt> : <!pt>, !pt
    %ct_791 = ckks.mul_plain %ct_73, %pt_790 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_792 = ckks.rescale %ct_791 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_793 = preprocessing.load %arg5[] site 204<!pt> : <!pt>, !pt
    %ct_794 = ckks.mul_plain %ct_77, %pt_793 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_795 = ckks.rescale %ct_794 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_796 = preprocessing.load %arg5[] site 205<!pt> : <!pt>, !pt
    %ct_797 = ckks.mul_plain %ct_81, %pt_796 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_798 = ckks.rescale %ct_797 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_799 = preprocessing.load %arg5[] site 206<!pt> : <!pt>, !pt
    %ct_800 = ckks.mul_plain %ct_85, %pt_799 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_801 = ckks.rescale %ct_800 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_802 = ckks.add %ct_735, %ct_738 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_803 = ckks.add %ct_741, %ct_744 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_804 = ckks.add %ct_803, %ct_747 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_805 = ckks.add %ct_802, %ct_804 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_806 = ckks.add %ct_750, %ct_753 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_807 = ckks.add %ct_806, %ct_756 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_808 = ckks.add %ct_759, %ct_762 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_809 = ckks.add %ct_808, %ct_765 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_810 = ckks.add %ct_807, %ct_809 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_811 = ckks.add %ct_805, %ct_810 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_812 = ckks.add %ct_768, %ct_771 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_813 = ckks.add %ct_812, %ct_774 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_814 = ckks.add %ct_777, %ct_780 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_815 = ckks.add %ct_814, %ct_783 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_816 = ckks.add %ct_813, %ct_815 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_817 = ckks.add %ct_786, %ct_789 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_818 = ckks.add %ct_817, %ct_792 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_819 = ckks.add %ct_795, %ct_798 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_820 = ckks.add %ct_819, %ct_801 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_821 = ckks.add %ct_818, %ct_820 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_822 = ckks.add %ct_816, %ct_821 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_823 = ckks.add %ct_811, %ct_822 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_824 = ckks.rotate %ct_823, %c184 : index : !ct_L5
    %pt_825 = preprocessing.load %arg5[] site 207<!pt> : <!pt>, !pt
    %ct_826 = ckks.mul_plain %extracted, %pt_825 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_827 = ckks.rescale %ct_826 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_828 = preprocessing.load %arg5[] site 208<!pt> : <!pt>, !pt
    %ct_829 = ckks.mul_plain %ct_1, %pt_828 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_830 = ckks.rescale %ct_829 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_831 = preprocessing.load %arg5[] site 209<!pt> : <!pt>, !pt
    %ct_832 = ckks.mul_plain %ct_5, %pt_831 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_833 = ckks.rescale %ct_832 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_834 = preprocessing.load %arg5[] site 210<!pt> : <!pt>, !pt
    %ct_835 = ckks.mul_plain %ct_9, %pt_834 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_836 = ckks.rescale %ct_835 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_837 = preprocessing.load %arg5[] site 211<!pt> : <!pt>, !pt
    %ct_838 = ckks.mul_plain %ct_13, %pt_837 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_839 = ckks.rescale %ct_838 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_840 = preprocessing.load %arg5[] site 212<!pt> : <!pt>, !pt
    %ct_841 = ckks.mul_plain %ct_17, %pt_840 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_842 = ckks.rescale %ct_841 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_843 = preprocessing.load %arg5[] site 213<!pt> : <!pt>, !pt
    %ct_844 = ckks.mul_plain %ct_21, %pt_843 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_845 = ckks.rescale %ct_844 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_846 = preprocessing.load %arg5[] site 214<!pt> : <!pt>, !pt
    %ct_847 = ckks.mul_plain %ct_25, %pt_846 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_848 = ckks.rescale %ct_847 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_849 = preprocessing.load %arg5[] site 215<!pt> : <!pt>, !pt
    %ct_850 = ckks.mul_plain %ct_29, %pt_849 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_851 = ckks.rescale %ct_850 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_852 = preprocessing.load %arg5[] site 216<!pt> : <!pt>, !pt
    %ct_853 = ckks.mul_plain %ct_33, %pt_852 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_854 = ckks.rescale %ct_853 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_855 = preprocessing.load %arg5[] site 217<!pt> : <!pt>, !pt
    %ct_856 = ckks.mul_plain %ct_37, %pt_855 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_857 = ckks.rescale %ct_856 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_858 = preprocessing.load %arg5[] site 218<!pt> : <!pt>, !pt
    %ct_859 = ckks.mul_plain %ct_41, %pt_858 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_860 = ckks.rescale %ct_859 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_861 = preprocessing.load %arg5[] site 219<!pt> : <!pt>, !pt
    %ct_862 = ckks.mul_plain %ct_45, %pt_861 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_863 = ckks.rescale %ct_862 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_864 = preprocessing.load %arg5[] site 220<!pt> : <!pt>, !pt
    %ct_865 = ckks.mul_plain %ct_49, %pt_864 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_866 = ckks.rescale %ct_865 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_867 = preprocessing.load %arg5[] site 221<!pt> : <!pt>, !pt
    %ct_868 = ckks.mul_plain %ct_53, %pt_867 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_869 = ckks.rescale %ct_868 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_870 = preprocessing.load %arg5[] site 222<!pt> : <!pt>, !pt
    %ct_871 = ckks.mul_plain %ct_57, %pt_870 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_872 = ckks.rescale %ct_871 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_873 = preprocessing.load %arg5[] site 223<!pt> : <!pt>, !pt
    %ct_874 = ckks.mul_plain %ct_61, %pt_873 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_875 = ckks.rescale %ct_874 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_876 = preprocessing.load %arg5[] site 224<!pt> : <!pt>, !pt
    %ct_877 = ckks.mul_plain %ct_65, %pt_876 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_878 = ckks.rescale %ct_877 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_879 = preprocessing.load %arg5[] site 225<!pt> : <!pt>, !pt
    %ct_880 = ckks.mul_plain %ct_69, %pt_879 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_881 = ckks.rescale %ct_880 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_882 = preprocessing.load %arg5[] site 226<!pt> : <!pt>, !pt
    %ct_883 = ckks.mul_plain %ct_73, %pt_882 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_884 = ckks.rescale %ct_883 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_885 = preprocessing.load %arg5[] site 227<!pt> : <!pt>, !pt
    %ct_886 = ckks.mul_plain %ct_77, %pt_885 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_887 = ckks.rescale %ct_886 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_888 = preprocessing.load %arg5[] site 228<!pt> : <!pt>, !pt
    %ct_889 = ckks.mul_plain %ct_81, %pt_888 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_890 = ckks.rescale %ct_889 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_891 = preprocessing.load %arg5[] site 229<!pt> : <!pt>, !pt
    %ct_892 = ckks.mul_plain %ct_85, %pt_891 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_893 = ckks.rescale %ct_892 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_894 = ckks.add %ct_827, %ct_830 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_895 = ckks.add %ct_833, %ct_836 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_896 = ckks.add %ct_895, %ct_839 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_897 = ckks.add %ct_894, %ct_896 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_898 = ckks.add %ct_842, %ct_845 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_899 = ckks.add %ct_898, %ct_848 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_900 = ckks.add %ct_851, %ct_854 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_901 = ckks.add %ct_900, %ct_857 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_902 = ckks.add %ct_899, %ct_901 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_903 = ckks.add %ct_897, %ct_902 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_904 = ckks.add %ct_860, %ct_863 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_905 = ckks.add %ct_904, %ct_866 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_906 = ckks.add %ct_869, %ct_872 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_907 = ckks.add %ct_906, %ct_875 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_908 = ckks.add %ct_905, %ct_907 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_909 = ckks.add %ct_878, %ct_881 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_910 = ckks.add %ct_909, %ct_884 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_911 = ckks.add %ct_887, %ct_890 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_912 = ckks.add %ct_911, %ct_893 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_913 = ckks.add %ct_910, %ct_912 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_914 = ckks.add %ct_908, %ct_913 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_915 = ckks.add %ct_903, %ct_914 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_916 = ckks.rotate %ct_915, %c207 : index : !ct_L5
    %pt_917 = preprocessing.load %arg5[] site 230<!pt> : <!pt>, !pt
    %ct_918 = ckks.mul_plain %extracted, %pt_917 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_919 = ckks.rescale %ct_918 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_920 = preprocessing.load %arg5[] site 231<!pt> : <!pt>, !pt
    %ct_921 = ckks.mul_plain %ct_1, %pt_920 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_922 = ckks.rescale %ct_921 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_923 = preprocessing.load %arg5[] site 232<!pt> : <!pt>, !pt
    %ct_924 = ckks.mul_plain %ct_5, %pt_923 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_925 = ckks.rescale %ct_924 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_926 = preprocessing.load %arg5[] site 233<!pt> : <!pt>, !pt
    %ct_927 = ckks.mul_plain %ct_9, %pt_926 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_928 = ckks.rescale %ct_927 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_929 = preprocessing.load %arg5[] site 234<!pt> : <!pt>, !pt
    %ct_930 = ckks.mul_plain %ct_13, %pt_929 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_931 = ckks.rescale %ct_930 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_932 = preprocessing.load %arg5[] site 235<!pt> : <!pt>, !pt
    %ct_933 = ckks.mul_plain %ct_17, %pt_932 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_934 = ckks.rescale %ct_933 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_935 = preprocessing.load %arg5[] site 236<!pt> : <!pt>, !pt
    %ct_936 = ckks.mul_plain %ct_21, %pt_935 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_937 = ckks.rescale %ct_936 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_938 = preprocessing.load %arg5[] site 237<!pt> : <!pt>, !pt
    %ct_939 = ckks.mul_plain %ct_25, %pt_938 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_940 = ckks.rescale %ct_939 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_941 = preprocessing.load %arg5[] site 238<!pt> : <!pt>, !pt
    %ct_942 = ckks.mul_plain %ct_29, %pt_941 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_943 = ckks.rescale %ct_942 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_944 = preprocessing.load %arg5[] site 239<!pt> : <!pt>, !pt
    %ct_945 = ckks.mul_plain %ct_33, %pt_944 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_946 = ckks.rescale %ct_945 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_947 = preprocessing.load %arg5[] site 240<!pt> : <!pt>, !pt
    %ct_948 = ckks.mul_plain %ct_37, %pt_947 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_949 = ckks.rescale %ct_948 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_950 = preprocessing.load %arg5[] site 241<!pt> : <!pt>, !pt
    %ct_951 = ckks.mul_plain %ct_41, %pt_950 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_952 = ckks.rescale %ct_951 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_953 = preprocessing.load %arg5[] site 242<!pt> : <!pt>, !pt
    %ct_954 = ckks.mul_plain %ct_45, %pt_953 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_955 = ckks.rescale %ct_954 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_956 = preprocessing.load %arg5[] site 243<!pt> : <!pt>, !pt
    %ct_957 = ckks.mul_plain %ct_49, %pt_956 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_958 = ckks.rescale %ct_957 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_959 = preprocessing.load %arg5[] site 244<!pt> : <!pt>, !pt
    %ct_960 = ckks.mul_plain %ct_53, %pt_959 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_961 = ckks.rescale %ct_960 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_962 = preprocessing.load %arg5[] site 245<!pt> : <!pt>, !pt
    %ct_963 = ckks.mul_plain %ct_57, %pt_962 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_964 = ckks.rescale %ct_963 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_965 = preprocessing.load %arg5[] site 246<!pt> : <!pt>, !pt
    %ct_966 = ckks.mul_plain %ct_61, %pt_965 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_967 = ckks.rescale %ct_966 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_968 = preprocessing.load %arg5[] site 247<!pt> : <!pt>, !pt
    %ct_969 = ckks.mul_plain %ct_65, %pt_968 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_970 = ckks.rescale %ct_969 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_971 = preprocessing.load %arg5[] site 248<!pt> : <!pt>, !pt
    %ct_972 = ckks.mul_plain %ct_69, %pt_971 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_973 = ckks.rescale %ct_972 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_974 = preprocessing.load %arg5[] site 249<!pt> : <!pt>, !pt
    %ct_975 = ckks.mul_plain %ct_73, %pt_974 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_976 = ckks.rescale %ct_975 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_977 = preprocessing.load %arg5[] site 250<!pt> : <!pt>, !pt
    %ct_978 = ckks.mul_plain %ct_77, %pt_977 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_979 = ckks.rescale %ct_978 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_980 = preprocessing.load %arg5[] site 251<!pt> : <!pt>, !pt
    %ct_981 = ckks.mul_plain %ct_81, %pt_980 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_982 = ckks.rescale %ct_981 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_983 = preprocessing.load %arg5[] site 252<!pt> : <!pt>, !pt
    %ct_984 = ckks.mul_plain %ct_85, %pt_983 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_985 = ckks.rescale %ct_984 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_986 = ckks.add %ct_919, %ct_922 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_987 = ckks.add %ct_925, %ct_928 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_988 = ckks.add %ct_987, %ct_931 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_989 = ckks.add %ct_986, %ct_988 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_990 = ckks.add %ct_934, %ct_937 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_991 = ckks.add %ct_990, %ct_940 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_992 = ckks.add %ct_943, %ct_946 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_993 = ckks.add %ct_992, %ct_949 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_994 = ckks.add %ct_991, %ct_993 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_995 = ckks.add %ct_989, %ct_994 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_996 = ckks.add %ct_952, %ct_955 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_997 = ckks.add %ct_996, %ct_958 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_998 = ckks.add %ct_961, %ct_964 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_999 = ckks.add %ct_998, %ct_967 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1000 = ckks.add %ct_997, %ct_999 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1001 = ckks.add %ct_970, %ct_973 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1002 = ckks.add %ct_1001, %ct_976 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1003 = ckks.add %ct_979, %ct_982 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1004 = ckks.add %ct_1003, %ct_985 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1005 = ckks.add %ct_1002, %ct_1004 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1006 = ckks.add %ct_1000, %ct_1005 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1007 = ckks.add %ct_995, %ct_1006 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1008 = ckks.rotate %ct_1007, %c230 : index : !ct_L5
    %pt_1009 = preprocessing.load %arg5[] site 253<!pt> : <!pt>, !pt
    %ct_1010 = ckks.mul_plain %extracted, %pt_1009 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1011 = ckks.rescale %ct_1010 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1012 = preprocessing.load %arg5[] site 254<!pt> : <!pt>, !pt
    %ct_1013 = ckks.mul_plain %ct_1, %pt_1012 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1014 = ckks.rescale %ct_1013 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1015 = preprocessing.load %arg5[] site 255<!pt> : <!pt>, !pt
    %ct_1016 = ckks.mul_plain %ct_5, %pt_1015 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1017 = ckks.rescale %ct_1016 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1018 = preprocessing.load %arg5[] site 256<!pt> : <!pt>, !pt
    %ct_1019 = ckks.mul_plain %ct_9, %pt_1018 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1020 = ckks.rescale %ct_1019 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1021 = preprocessing.load %arg5[] site 257<!pt> : <!pt>, !pt
    %ct_1022 = ckks.mul_plain %ct_13, %pt_1021 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1023 = ckks.rescale %ct_1022 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1024 = preprocessing.load %arg5[] site 258<!pt> : <!pt>, !pt
    %ct_1025 = ckks.mul_plain %ct_17, %pt_1024 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1026 = ckks.rescale %ct_1025 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1027 = preprocessing.load %arg5[] site 259<!pt> : <!pt>, !pt
    %ct_1028 = ckks.mul_plain %ct_21, %pt_1027 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1029 = ckks.rescale %ct_1028 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1030 = preprocessing.load %arg5[] site 260<!pt> : <!pt>, !pt
    %ct_1031 = ckks.mul_plain %ct_25, %pt_1030 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1032 = ckks.rescale %ct_1031 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1033 = preprocessing.load %arg5[] site 261<!pt> : <!pt>, !pt
    %ct_1034 = ckks.mul_plain %ct_29, %pt_1033 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1035 = ckks.rescale %ct_1034 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1036 = preprocessing.load %arg5[] site 262<!pt> : <!pt>, !pt
    %ct_1037 = ckks.mul_plain %ct_33, %pt_1036 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1038 = ckks.rescale %ct_1037 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1039 = preprocessing.load %arg5[] site 263<!pt> : <!pt>, !pt
    %ct_1040 = ckks.mul_plain %ct_37, %pt_1039 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1041 = ckks.rescale %ct_1040 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1042 = preprocessing.load %arg5[] site 264<!pt> : <!pt>, !pt
    %ct_1043 = ckks.mul_plain %ct_41, %pt_1042 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1044 = ckks.rescale %ct_1043 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1045 = preprocessing.load %arg5[] site 265<!pt> : <!pt>, !pt
    %ct_1046 = ckks.mul_plain %ct_45, %pt_1045 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1047 = ckks.rescale %ct_1046 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1048 = preprocessing.load %arg5[] site 266<!pt> : <!pt>, !pt
    %ct_1049 = ckks.mul_plain %ct_49, %pt_1048 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1050 = ckks.rescale %ct_1049 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1051 = preprocessing.load %arg5[] site 267<!pt> : <!pt>, !pt
    %ct_1052 = ckks.mul_plain %ct_53, %pt_1051 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1053 = ckks.rescale %ct_1052 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1054 = preprocessing.load %arg5[] site 268<!pt> : <!pt>, !pt
    %ct_1055 = ckks.mul_plain %ct_57, %pt_1054 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1056 = ckks.rescale %ct_1055 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1057 = preprocessing.load %arg5[] site 269<!pt> : <!pt>, !pt
    %ct_1058 = ckks.mul_plain %ct_61, %pt_1057 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1059 = ckks.rescale %ct_1058 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1060 = preprocessing.load %arg5[] site 270<!pt> : <!pt>, !pt
    %ct_1061 = ckks.mul_plain %ct_65, %pt_1060 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1062 = ckks.rescale %ct_1061 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1063 = preprocessing.load %arg5[] site 271<!pt> : <!pt>, !pt
    %ct_1064 = ckks.mul_plain %ct_69, %pt_1063 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1065 = ckks.rescale %ct_1064 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1066 = preprocessing.load %arg5[] site 272<!pt> : <!pt>, !pt
    %ct_1067 = ckks.mul_plain %ct_73, %pt_1066 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1068 = ckks.rescale %ct_1067 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1069 = preprocessing.load %arg5[] site 273<!pt> : <!pt>, !pt
    %ct_1070 = ckks.mul_plain %ct_77, %pt_1069 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1071 = ckks.rescale %ct_1070 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1072 = preprocessing.load %arg5[] site 274<!pt> : <!pt>, !pt
    %ct_1073 = ckks.mul_plain %ct_81, %pt_1072 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1074 = ckks.rescale %ct_1073 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1075 = preprocessing.load %arg5[] site 275<!pt> : <!pt>, !pt
    %ct_1076 = ckks.mul_plain %ct_85, %pt_1075 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1077 = ckks.rescale %ct_1076 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_1078 = ckks.add %ct_1011, %ct_1014 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1079 = ckks.add %ct_1017, %ct_1020 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1080 = ckks.add %ct_1079, %ct_1023 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1081 = ckks.add %ct_1078, %ct_1080 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1082 = ckks.add %ct_1026, %ct_1029 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1083 = ckks.add %ct_1082, %ct_1032 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1084 = ckks.add %ct_1035, %ct_1038 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1085 = ckks.add %ct_1084, %ct_1041 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1086 = ckks.add %ct_1083, %ct_1085 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1087 = ckks.add %ct_1081, %ct_1086 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1088 = ckks.add %ct_1044, %ct_1047 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1089 = ckks.add %ct_1088, %ct_1050 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1090 = ckks.add %ct_1053, %ct_1056 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1091 = ckks.add %ct_1090, %ct_1059 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1092 = ckks.add %ct_1089, %ct_1091 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1093 = ckks.add %ct_1062, %ct_1065 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1094 = ckks.add %ct_1093, %ct_1068 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1095 = ckks.add %ct_1071, %ct_1074 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1096 = ckks.add %ct_1095, %ct_1077 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1097 = ckks.add %ct_1094, %ct_1096 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1098 = ckks.add %ct_1092, %ct_1097 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1099 = ckks.add %ct_1087, %ct_1098 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1100 = ckks.rotate %ct_1099, %c253 : index : !ct_L5
    %pt_1101 = preprocessing.load %arg5[] site 276<!pt> : <!pt>, !pt
    %ct_1102 = ckks.mul_plain %extracted, %pt_1101 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1103 = ckks.rescale %ct_1102 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1104 = preprocessing.load %arg5[] site 277<!pt> : <!pt>, !pt
    %ct_1105 = ckks.mul_plain %ct_1, %pt_1104 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1106 = ckks.rescale %ct_1105 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1107 = preprocessing.load %arg5[] site 278<!pt> : <!pt>, !pt
    %ct_1108 = ckks.mul_plain %ct_5, %pt_1107 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1109 = ckks.rescale %ct_1108 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1110 = preprocessing.load %arg5[] site 279<!pt> : <!pt>, !pt
    %ct_1111 = ckks.mul_plain %ct_9, %pt_1110 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1112 = ckks.rescale %ct_1111 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1113 = preprocessing.load %arg5[] site 280<!pt> : <!pt>, !pt
    %ct_1114 = ckks.mul_plain %ct_13, %pt_1113 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1115 = ckks.rescale %ct_1114 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1116 = preprocessing.load %arg5[] site 281<!pt> : <!pt>, !pt
    %ct_1117 = ckks.mul_plain %ct_17, %pt_1116 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1118 = ckks.rescale %ct_1117 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1119 = preprocessing.load %arg5[] site 282<!pt> : <!pt>, !pt
    %ct_1120 = ckks.mul_plain %ct_21, %pt_1119 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1121 = ckks.rescale %ct_1120 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1122 = preprocessing.load %arg5[] site 283<!pt> : <!pt>, !pt
    %ct_1123 = ckks.mul_plain %ct_25, %pt_1122 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1124 = ckks.rescale %ct_1123 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1125 = preprocessing.load %arg5[] site 284<!pt> : <!pt>, !pt
    %ct_1126 = ckks.mul_plain %ct_29, %pt_1125 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1127 = ckks.rescale %ct_1126 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1128 = preprocessing.load %arg5[] site 285<!pt> : <!pt>, !pt
    %ct_1129 = ckks.mul_plain %ct_33, %pt_1128 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1130 = ckks.rescale %ct_1129 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1131 = preprocessing.load %arg5[] site 286<!pt> : <!pt>, !pt
    %ct_1132 = ckks.mul_plain %ct_37, %pt_1131 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1133 = ckks.rescale %ct_1132 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1134 = preprocessing.load %arg5[] site 287<!pt> : <!pt>, !pt
    %ct_1135 = ckks.mul_plain %ct_41, %pt_1134 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1136 = ckks.rescale %ct_1135 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1137 = preprocessing.load %arg5[] site 288<!pt> : <!pt>, !pt
    %ct_1138 = ckks.mul_plain %ct_45, %pt_1137 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1139 = ckks.rescale %ct_1138 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1140 = preprocessing.load %arg5[] site 289<!pt> : <!pt>, !pt
    %ct_1141 = ckks.mul_plain %ct_49, %pt_1140 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1142 = ckks.rescale %ct_1141 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1143 = preprocessing.load %arg5[] site 290<!pt> : <!pt>, !pt
    %ct_1144 = ckks.mul_plain %ct_53, %pt_1143 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1145 = ckks.rescale %ct_1144 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1146 = preprocessing.load %arg5[] site 291<!pt> : <!pt>, !pt
    %ct_1147 = ckks.mul_plain %ct_57, %pt_1146 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1148 = ckks.rescale %ct_1147 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1149 = preprocessing.load %arg5[] site 292<!pt> : <!pt>, !pt
    %ct_1150 = ckks.mul_plain %ct_61, %pt_1149 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1151 = ckks.rescale %ct_1150 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1152 = preprocessing.load %arg5[] site 293<!pt> : <!pt>, !pt
    %ct_1153 = ckks.mul_plain %ct_65, %pt_1152 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1154 = ckks.rescale %ct_1153 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1155 = preprocessing.load %arg5[] site 294<!pt> : <!pt>, !pt
    %ct_1156 = ckks.mul_plain %ct_69, %pt_1155 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1157 = ckks.rescale %ct_1156 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1158 = preprocessing.load %arg5[] site 295<!pt> : <!pt>, !pt
    %ct_1159 = ckks.mul_plain %ct_73, %pt_1158 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1160 = ckks.rescale %ct_1159 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1161 = preprocessing.load %arg5[] site 296<!pt> : <!pt>, !pt
    %ct_1162 = ckks.mul_plain %ct_77, %pt_1161 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1163 = ckks.rescale %ct_1162 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1164 = preprocessing.load %arg5[] site 297<!pt> : <!pt>, !pt
    %ct_1165 = ckks.mul_plain %ct_81, %pt_1164 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1166 = ckks.rescale %ct_1165 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1167 = preprocessing.load %arg5[] site 298<!pt> : <!pt>, !pt
    %ct_1168 = ckks.mul_plain %ct_85, %pt_1167 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1169 = ckks.rescale %ct_1168 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_1170 = ckks.add %ct_1103, %ct_1106 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1171 = ckks.add %ct_1109, %ct_1112 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1172 = ckks.add %ct_1171, %ct_1115 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1173 = ckks.add %ct_1170, %ct_1172 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1174 = ckks.add %ct_1118, %ct_1121 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1175 = ckks.add %ct_1174, %ct_1124 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1176 = ckks.add %ct_1127, %ct_1130 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1177 = ckks.add %ct_1176, %ct_1133 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1178 = ckks.add %ct_1175, %ct_1177 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1179 = ckks.add %ct_1173, %ct_1178 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1180 = ckks.add %ct_1136, %ct_1139 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1181 = ckks.add %ct_1180, %ct_1142 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1182 = ckks.add %ct_1145, %ct_1148 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1183 = ckks.add %ct_1182, %ct_1151 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1184 = ckks.add %ct_1181, %ct_1183 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1185 = ckks.add %ct_1154, %ct_1157 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1186 = ckks.add %ct_1185, %ct_1160 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1187 = ckks.add %ct_1163, %ct_1166 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1188 = ckks.add %ct_1187, %ct_1169 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1189 = ckks.add %ct_1186, %ct_1188 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1190 = ckks.add %ct_1184, %ct_1189 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1191 = ckks.add %ct_1179, %ct_1190 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1192 = ckks.rotate %ct_1191, %c276 : index : !ct_L5
    %pt_1193 = preprocessing.load %arg5[] site 299<!pt> : <!pt>, !pt
    %ct_1194 = ckks.mul_plain %extracted, %pt_1193 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1195 = ckks.rescale %ct_1194 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1196 = preprocessing.load %arg5[] site 300<!pt> : <!pt>, !pt
    %ct_1197 = ckks.mul_plain %ct_1, %pt_1196 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1198 = ckks.rescale %ct_1197 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1199 = preprocessing.load %arg5[] site 301<!pt> : <!pt>, !pt
    %ct_1200 = ckks.mul_plain %ct_5, %pt_1199 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1201 = ckks.rescale %ct_1200 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1202 = preprocessing.load %arg5[] site 302<!pt> : <!pt>, !pt
    %ct_1203 = ckks.mul_plain %ct_9, %pt_1202 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1204 = ckks.rescale %ct_1203 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1205 = preprocessing.load %arg5[] site 303<!pt> : <!pt>, !pt
    %ct_1206 = ckks.mul_plain %ct_13, %pt_1205 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1207 = ckks.rescale %ct_1206 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1208 = preprocessing.load %arg5[] site 304<!pt> : <!pt>, !pt
    %ct_1209 = ckks.mul_plain %ct_17, %pt_1208 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1210 = ckks.rescale %ct_1209 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1211 = preprocessing.load %arg5[] site 305<!pt> : <!pt>, !pt
    %ct_1212 = ckks.mul_plain %ct_21, %pt_1211 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1213 = ckks.rescale %ct_1212 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1214 = preprocessing.load %arg5[] site 306<!pt> : <!pt>, !pt
    %ct_1215 = ckks.mul_plain %ct_25, %pt_1214 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1216 = ckks.rescale %ct_1215 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1217 = preprocessing.load %arg5[] site 307<!pt> : <!pt>, !pt
    %ct_1218 = ckks.mul_plain %ct_29, %pt_1217 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1219 = ckks.rescale %ct_1218 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1220 = preprocessing.load %arg5[] site 308<!pt> : <!pt>, !pt
    %ct_1221 = ckks.mul_plain %ct_33, %pt_1220 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1222 = ckks.rescale %ct_1221 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1223 = preprocessing.load %arg5[] site 309<!pt> : <!pt>, !pt
    %ct_1224 = ckks.mul_plain %ct_37, %pt_1223 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1225 = ckks.rescale %ct_1224 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1226 = preprocessing.load %arg5[] site 310<!pt> : <!pt>, !pt
    %ct_1227 = ckks.mul_plain %ct_41, %pt_1226 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1228 = ckks.rescale %ct_1227 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1229 = preprocessing.load %arg5[] site 311<!pt> : <!pt>, !pt
    %ct_1230 = ckks.mul_plain %ct_45, %pt_1229 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1231 = ckks.rescale %ct_1230 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1232 = preprocessing.load %arg5[] site 312<!pt> : <!pt>, !pt
    %ct_1233 = ckks.mul_plain %ct_49, %pt_1232 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1234 = ckks.rescale %ct_1233 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1235 = preprocessing.load %arg5[] site 313<!pt> : <!pt>, !pt
    %ct_1236 = ckks.mul_plain %ct_53, %pt_1235 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1237 = ckks.rescale %ct_1236 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1238 = preprocessing.load %arg5[] site 314<!pt> : <!pt>, !pt
    %ct_1239 = ckks.mul_plain %ct_57, %pt_1238 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1240 = ckks.rescale %ct_1239 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1241 = preprocessing.load %arg5[] site 315<!pt> : <!pt>, !pt
    %ct_1242 = ckks.mul_plain %ct_61, %pt_1241 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1243 = ckks.rescale %ct_1242 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1244 = preprocessing.load %arg5[] site 316<!pt> : <!pt>, !pt
    %ct_1245 = ckks.mul_plain %ct_65, %pt_1244 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1246 = ckks.rescale %ct_1245 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1247 = preprocessing.load %arg5[] site 317<!pt> : <!pt>, !pt
    %ct_1248 = ckks.mul_plain %ct_69, %pt_1247 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1249 = ckks.rescale %ct_1248 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1250 = preprocessing.load %arg5[] site 318<!pt> : <!pt>, !pt
    %ct_1251 = ckks.mul_plain %ct_73, %pt_1250 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1252 = ckks.rescale %ct_1251 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1253 = preprocessing.load %arg5[] site 319<!pt> : <!pt>, !pt
    %ct_1254 = ckks.mul_plain %ct_77, %pt_1253 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1255 = ckks.rescale %ct_1254 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1256 = preprocessing.load %arg5[] site 320<!pt> : <!pt>, !pt
    %ct_1257 = ckks.mul_plain %ct_81, %pt_1256 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1258 = ckks.rescale %ct_1257 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1259 = preprocessing.load %arg5[] site 321<!pt> : <!pt>, !pt
    %ct_1260 = ckks.mul_plain %ct_85, %pt_1259 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1261 = ckks.rescale %ct_1260 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_1262 = ckks.add %ct_1195, %ct_1198 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1263 = ckks.add %ct_1201, %ct_1204 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1264 = ckks.add %ct_1263, %ct_1207 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1265 = ckks.add %ct_1262, %ct_1264 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1266 = ckks.add %ct_1210, %ct_1213 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1267 = ckks.add %ct_1266, %ct_1216 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1268 = ckks.add %ct_1219, %ct_1222 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1269 = ckks.add %ct_1268, %ct_1225 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1270 = ckks.add %ct_1267, %ct_1269 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1271 = ckks.add %ct_1265, %ct_1270 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1272 = ckks.add %ct_1228, %ct_1231 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1273 = ckks.add %ct_1272, %ct_1234 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1274 = ckks.add %ct_1237, %ct_1240 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1275 = ckks.add %ct_1274, %ct_1243 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1276 = ckks.add %ct_1273, %ct_1275 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1277 = ckks.add %ct_1246, %ct_1249 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1278 = ckks.add %ct_1277, %ct_1252 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1279 = ckks.add %ct_1255, %ct_1258 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1280 = ckks.add %ct_1279, %ct_1261 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1281 = ckks.add %ct_1278, %ct_1280 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1282 = ckks.add %ct_1276, %ct_1281 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1283 = ckks.add %ct_1271, %ct_1282 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1284 = ckks.rotate %ct_1283, %c299 : index : !ct_L5
    %pt_1285 = preprocessing.load %arg5[] site 322<!pt> : <!pt>, !pt
    %ct_1286 = ckks.mul_plain %extracted, %pt_1285 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1287 = ckks.rescale %ct_1286 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1288 = preprocessing.load %arg5[] site 323<!pt> : <!pt>, !pt
    %ct_1289 = ckks.mul_plain %ct_1, %pt_1288 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1290 = ckks.rescale %ct_1289 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1291 = preprocessing.load %arg5[] site 324<!pt> : <!pt>, !pt
    %ct_1292 = ckks.mul_plain %ct_5, %pt_1291 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1293 = ckks.rescale %ct_1292 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1294 = preprocessing.load %arg5[] site 325<!pt> : <!pt>, !pt
    %ct_1295 = ckks.mul_plain %ct_9, %pt_1294 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1296 = ckks.rescale %ct_1295 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1297 = preprocessing.load %arg5[] site 326<!pt> : <!pt>, !pt
    %ct_1298 = ckks.mul_plain %ct_13, %pt_1297 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1299 = ckks.rescale %ct_1298 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1300 = preprocessing.load %arg5[] site 327<!pt> : <!pt>, !pt
    %ct_1301 = ckks.mul_plain %ct_17, %pt_1300 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1302 = ckks.rescale %ct_1301 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1303 = preprocessing.load %arg5[] site 328<!pt> : <!pt>, !pt
    %ct_1304 = ckks.mul_plain %ct_21, %pt_1303 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1305 = ckks.rescale %ct_1304 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1306 = preprocessing.load %arg5[] site 329<!pt> : <!pt>, !pt
    %ct_1307 = ckks.mul_plain %ct_25, %pt_1306 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1308 = ckks.rescale %ct_1307 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1309 = preprocessing.load %arg5[] site 330<!pt> : <!pt>, !pt
    %ct_1310 = ckks.mul_plain %ct_29, %pt_1309 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1311 = ckks.rescale %ct_1310 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1312 = preprocessing.load %arg5[] site 331<!pt> : <!pt>, !pt
    %ct_1313 = ckks.mul_plain %ct_33, %pt_1312 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1314 = ckks.rescale %ct_1313 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1315 = preprocessing.load %arg5[] site 332<!pt> : <!pt>, !pt
    %ct_1316 = ckks.mul_plain %ct_37, %pt_1315 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1317 = ckks.rescale %ct_1316 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1318 = preprocessing.load %arg5[] site 333<!pt> : <!pt>, !pt
    %ct_1319 = ckks.mul_plain %ct_41, %pt_1318 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1320 = ckks.rescale %ct_1319 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1321 = preprocessing.load %arg5[] site 334<!pt> : <!pt>, !pt
    %ct_1322 = ckks.mul_plain %ct_45, %pt_1321 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1323 = ckks.rescale %ct_1322 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1324 = preprocessing.load %arg5[] site 335<!pt> : <!pt>, !pt
    %ct_1325 = ckks.mul_plain %ct_49, %pt_1324 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1326 = ckks.rescale %ct_1325 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1327 = preprocessing.load %arg5[] site 336<!pt> : <!pt>, !pt
    %ct_1328 = ckks.mul_plain %ct_53, %pt_1327 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1329 = ckks.rescale %ct_1328 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1330 = preprocessing.load %arg5[] site 337<!pt> : <!pt>, !pt
    %ct_1331 = ckks.mul_plain %ct_57, %pt_1330 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1332 = ckks.rescale %ct_1331 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1333 = preprocessing.load %arg5[] site 338<!pt> : <!pt>, !pt
    %ct_1334 = ckks.mul_plain %ct_61, %pt_1333 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1335 = ckks.rescale %ct_1334 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1336 = preprocessing.load %arg5[] site 339<!pt> : <!pt>, !pt
    %ct_1337 = ckks.mul_plain %ct_65, %pt_1336 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1338 = ckks.rescale %ct_1337 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1339 = preprocessing.load %arg5[] site 340<!pt> : <!pt>, !pt
    %ct_1340 = ckks.mul_plain %ct_69, %pt_1339 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1341 = ckks.rescale %ct_1340 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1342 = preprocessing.load %arg5[] site 341<!pt> : <!pt>, !pt
    %ct_1343 = ckks.mul_plain %ct_73, %pt_1342 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1344 = ckks.rescale %ct_1343 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1345 = preprocessing.load %arg5[] site 342<!pt> : <!pt>, !pt
    %ct_1346 = ckks.mul_plain %ct_77, %pt_1345 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1347 = ckks.rescale %ct_1346 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1348 = preprocessing.load %arg5[] site 343<!pt> : <!pt>, !pt
    %ct_1349 = ckks.mul_plain %ct_81, %pt_1348 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1350 = ckks.rescale %ct_1349 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1351 = preprocessing.load %arg5[] site 344<!pt> : <!pt>, !pt
    %ct_1352 = ckks.mul_plain %ct_85, %pt_1351 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1353 = ckks.rescale %ct_1352 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_1354 = ckks.add %ct_1287, %ct_1290 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1355 = ckks.add %ct_1293, %ct_1296 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1356 = ckks.add %ct_1355, %ct_1299 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1357 = ckks.add %ct_1354, %ct_1356 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1358 = ckks.add %ct_1302, %ct_1305 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1359 = ckks.add %ct_1358, %ct_1308 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1360 = ckks.add %ct_1311, %ct_1314 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1361 = ckks.add %ct_1360, %ct_1317 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1362 = ckks.add %ct_1359, %ct_1361 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1363 = ckks.add %ct_1357, %ct_1362 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1364 = ckks.add %ct_1320, %ct_1323 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1365 = ckks.add %ct_1364, %ct_1326 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1366 = ckks.add %ct_1329, %ct_1332 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1367 = ckks.add %ct_1366, %ct_1335 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1368 = ckks.add %ct_1365, %ct_1367 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1369 = ckks.add %ct_1338, %ct_1341 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1370 = ckks.add %ct_1369, %ct_1344 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1371 = ckks.add %ct_1347, %ct_1350 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1372 = ckks.add %ct_1371, %ct_1353 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1373 = ckks.add %ct_1370, %ct_1372 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1374 = ckks.add %ct_1368, %ct_1373 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1375 = ckks.add %ct_1363, %ct_1374 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1376 = ckks.rotate %ct_1375, %c322 : index : !ct_L5
    %pt_1377 = preprocessing.load %arg5[] site 345<!pt> : <!pt>, !pt
    %ct_1378 = ckks.mul_plain %extracted, %pt_1377 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1379 = ckks.rescale %ct_1378 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1380 = preprocessing.load %arg5[] site 346<!pt> : <!pt>, !pt
    %ct_1381 = ckks.mul_plain %ct_1, %pt_1380 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1382 = ckks.rescale %ct_1381 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1383 = preprocessing.load %arg5[] site 347<!pt> : <!pt>, !pt
    %ct_1384 = ckks.mul_plain %ct_5, %pt_1383 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1385 = ckks.rescale %ct_1384 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1386 = preprocessing.load %arg5[] site 348<!pt> : <!pt>, !pt
    %ct_1387 = ckks.mul_plain %ct_9, %pt_1386 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1388 = ckks.rescale %ct_1387 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1389 = preprocessing.load %arg5[] site 349<!pt> : <!pt>, !pt
    %ct_1390 = ckks.mul_plain %ct_13, %pt_1389 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1391 = ckks.rescale %ct_1390 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1392 = preprocessing.load %arg5[] site 350<!pt> : <!pt>, !pt
    %ct_1393 = ckks.mul_plain %ct_17, %pt_1392 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1394 = ckks.rescale %ct_1393 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1395 = preprocessing.load %arg5[] site 351<!pt> : <!pt>, !pt
    %ct_1396 = ckks.mul_plain %ct_21, %pt_1395 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1397 = ckks.rescale %ct_1396 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1398 = preprocessing.load %arg5[] site 352<!pt> : <!pt>, !pt
    %ct_1399 = ckks.mul_plain %ct_25, %pt_1398 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1400 = ckks.rescale %ct_1399 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1401 = preprocessing.load %arg5[] site 353<!pt> : <!pt>, !pt
    %ct_1402 = ckks.mul_plain %ct_29, %pt_1401 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1403 = ckks.rescale %ct_1402 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1404 = preprocessing.load %arg5[] site 354<!pt> : <!pt>, !pt
    %ct_1405 = ckks.mul_plain %ct_33, %pt_1404 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1406 = ckks.rescale %ct_1405 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1407 = preprocessing.load %arg5[] site 355<!pt> : <!pt>, !pt
    %ct_1408 = ckks.mul_plain %ct_37, %pt_1407 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1409 = ckks.rescale %ct_1408 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1410 = preprocessing.load %arg5[] site 356<!pt> : <!pt>, !pt
    %ct_1411 = ckks.mul_plain %ct_41, %pt_1410 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1412 = ckks.rescale %ct_1411 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1413 = preprocessing.load %arg5[] site 357<!pt> : <!pt>, !pt
    %ct_1414 = ckks.mul_plain %ct_45, %pt_1413 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1415 = ckks.rescale %ct_1414 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1416 = preprocessing.load %arg5[] site 358<!pt> : <!pt>, !pt
    %ct_1417 = ckks.mul_plain %ct_49, %pt_1416 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1418 = ckks.rescale %ct_1417 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1419 = preprocessing.load %arg5[] site 359<!pt> : <!pt>, !pt
    %ct_1420 = ckks.mul_plain %ct_53, %pt_1419 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1421 = ckks.rescale %ct_1420 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1422 = preprocessing.load %arg5[] site 360<!pt> : <!pt>, !pt
    %ct_1423 = ckks.mul_plain %ct_57, %pt_1422 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1424 = ckks.rescale %ct_1423 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1425 = preprocessing.load %arg5[] site 361<!pt> : <!pt>, !pt
    %ct_1426 = ckks.mul_plain %ct_61, %pt_1425 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1427 = ckks.rescale %ct_1426 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1428 = preprocessing.load %arg5[] site 362<!pt> : <!pt>, !pt
    %ct_1429 = ckks.mul_plain %ct_65, %pt_1428 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1430 = ckks.rescale %ct_1429 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1431 = preprocessing.load %arg5[] site 363<!pt> : <!pt>, !pt
    %ct_1432 = ckks.mul_plain %ct_69, %pt_1431 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1433 = ckks.rescale %ct_1432 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1434 = preprocessing.load %arg5[] site 364<!pt> : <!pt>, !pt
    %ct_1435 = ckks.mul_plain %ct_73, %pt_1434 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1436 = ckks.rescale %ct_1435 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1437 = preprocessing.load %arg5[] site 365<!pt> : <!pt>, !pt
    %ct_1438 = ckks.mul_plain %ct_77, %pt_1437 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1439 = ckks.rescale %ct_1438 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1440 = preprocessing.load %arg5[] site 366<!pt> : <!pt>, !pt
    %ct_1441 = ckks.mul_plain %ct_81, %pt_1440 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1442 = ckks.rescale %ct_1441 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1443 = preprocessing.load %arg5[] site 367<!pt> : <!pt>, !pt
    %ct_1444 = ckks.mul_plain %ct_85, %pt_1443 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1445 = ckks.rescale %ct_1444 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_1446 = ckks.add %ct_1379, %ct_1382 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1447 = ckks.add %ct_1385, %ct_1388 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1448 = ckks.add %ct_1447, %ct_1391 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1449 = ckks.add %ct_1446, %ct_1448 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1450 = ckks.add %ct_1394, %ct_1397 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1451 = ckks.add %ct_1450, %ct_1400 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1452 = ckks.add %ct_1403, %ct_1406 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1453 = ckks.add %ct_1452, %ct_1409 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1454 = ckks.add %ct_1451, %ct_1453 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1455 = ckks.add %ct_1449, %ct_1454 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1456 = ckks.add %ct_1412, %ct_1415 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1457 = ckks.add %ct_1456, %ct_1418 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1458 = ckks.add %ct_1421, %ct_1424 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1459 = ckks.add %ct_1458, %ct_1427 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1460 = ckks.add %ct_1457, %ct_1459 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1461 = ckks.add %ct_1430, %ct_1433 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1462 = ckks.add %ct_1461, %ct_1436 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1463 = ckks.add %ct_1439, %ct_1442 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1464 = ckks.add %ct_1463, %ct_1445 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1465 = ckks.add %ct_1462, %ct_1464 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1466 = ckks.add %ct_1460, %ct_1465 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1467 = ckks.add %ct_1455, %ct_1466 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1468 = ckks.rotate %ct_1467, %c345 : index : !ct_L5
    %pt_1469 = preprocessing.load %arg5[] site 368<!pt> : <!pt>, !pt
    %ct_1470 = ckks.mul_plain %extracted, %pt_1469 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1471 = ckks.rescale %ct_1470 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1472 = preprocessing.load %arg5[] site 369<!pt> : <!pt>, !pt
    %ct_1473 = ckks.mul_plain %ct_1, %pt_1472 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1474 = ckks.rescale %ct_1473 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1475 = preprocessing.load %arg5[] site 370<!pt> : <!pt>, !pt
    %ct_1476 = ckks.mul_plain %ct_5, %pt_1475 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1477 = ckks.rescale %ct_1476 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1478 = preprocessing.load %arg5[] site 371<!pt> : <!pt>, !pt
    %ct_1479 = ckks.mul_plain %ct_9, %pt_1478 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1480 = ckks.rescale %ct_1479 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1481 = preprocessing.load %arg5[] site 372<!pt> : <!pt>, !pt
    %ct_1482 = ckks.mul_plain %ct_13, %pt_1481 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1483 = ckks.rescale %ct_1482 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1484 = preprocessing.load %arg5[] site 373<!pt> : <!pt>, !pt
    %ct_1485 = ckks.mul_plain %ct_17, %pt_1484 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1486 = ckks.rescale %ct_1485 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1487 = preprocessing.load %arg5[] site 374<!pt> : <!pt>, !pt
    %ct_1488 = ckks.mul_plain %ct_21, %pt_1487 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1489 = ckks.rescale %ct_1488 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1490 = preprocessing.load %arg5[] site 375<!pt> : <!pt>, !pt
    %ct_1491 = ckks.mul_plain %ct_25, %pt_1490 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1492 = ckks.rescale %ct_1491 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1493 = preprocessing.load %arg5[] site 376<!pt> : <!pt>, !pt
    %ct_1494 = ckks.mul_plain %ct_29, %pt_1493 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1495 = ckks.rescale %ct_1494 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1496 = preprocessing.load %arg5[] site 377<!pt> : <!pt>, !pt
    %ct_1497 = ckks.mul_plain %ct_33, %pt_1496 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1498 = ckks.rescale %ct_1497 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1499 = preprocessing.load %arg5[] site 378<!pt> : <!pt>, !pt
    %ct_1500 = ckks.mul_plain %ct_37, %pt_1499 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1501 = ckks.rescale %ct_1500 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1502 = preprocessing.load %arg5[] site 379<!pt> : <!pt>, !pt
    %ct_1503 = ckks.mul_plain %ct_41, %pt_1502 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1504 = ckks.rescale %ct_1503 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1505 = preprocessing.load %arg5[] site 380<!pt> : <!pt>, !pt
    %ct_1506 = ckks.mul_plain %ct_45, %pt_1505 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1507 = ckks.rescale %ct_1506 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1508 = preprocessing.load %arg5[] site 381<!pt> : <!pt>, !pt
    %ct_1509 = ckks.mul_plain %ct_49, %pt_1508 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1510 = ckks.rescale %ct_1509 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1511 = preprocessing.load %arg5[] site 382<!pt> : <!pt>, !pt
    %ct_1512 = ckks.mul_plain %ct_53, %pt_1511 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1513 = ckks.rescale %ct_1512 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1514 = preprocessing.load %arg5[] site 383<!pt> : <!pt>, !pt
    %ct_1515 = ckks.mul_plain %ct_57, %pt_1514 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1516 = ckks.rescale %ct_1515 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1517 = preprocessing.load %arg5[] site 384<!pt> : <!pt>, !pt
    %ct_1518 = ckks.mul_plain %ct_61, %pt_1517 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1519 = ckks.rescale %ct_1518 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1520 = preprocessing.load %arg5[] site 385<!pt> : <!pt>, !pt
    %ct_1521 = ckks.mul_plain %ct_65, %pt_1520 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1522 = ckks.rescale %ct_1521 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1523 = preprocessing.load %arg5[] site 386<!pt> : <!pt>, !pt
    %ct_1524 = ckks.mul_plain %ct_69, %pt_1523 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1525 = ckks.rescale %ct_1524 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1526 = preprocessing.load %arg5[] site 387<!pt> : <!pt>, !pt
    %ct_1527 = ckks.mul_plain %ct_73, %pt_1526 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1528 = ckks.rescale %ct_1527 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1529 = preprocessing.load %arg5[] site 388<!pt> : <!pt>, !pt
    %ct_1530 = ckks.mul_plain %ct_77, %pt_1529 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1531 = ckks.rescale %ct_1530 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1532 = preprocessing.load %arg5[] site 389<!pt> : <!pt>, !pt
    %ct_1533 = ckks.mul_plain %ct_81, %pt_1532 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1534 = ckks.rescale %ct_1533 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1535 = preprocessing.load %arg5[] site 390<!pt> : <!pt>, !pt
    %ct_1536 = ckks.mul_plain %ct_85, %pt_1535 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1537 = ckks.rescale %ct_1536 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_1538 = ckks.add %ct_1471, %ct_1474 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1539 = ckks.add %ct_1477, %ct_1480 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1540 = ckks.add %ct_1539, %ct_1483 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1541 = ckks.add %ct_1538, %ct_1540 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1542 = ckks.add %ct_1486, %ct_1489 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1543 = ckks.add %ct_1542, %ct_1492 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1544 = ckks.add %ct_1495, %ct_1498 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1545 = ckks.add %ct_1544, %ct_1501 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1546 = ckks.add %ct_1543, %ct_1545 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1547 = ckks.add %ct_1541, %ct_1546 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1548 = ckks.add %ct_1504, %ct_1507 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1549 = ckks.add %ct_1548, %ct_1510 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1550 = ckks.add %ct_1513, %ct_1516 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1551 = ckks.add %ct_1550, %ct_1519 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1552 = ckks.add %ct_1549, %ct_1551 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1553 = ckks.add %ct_1522, %ct_1525 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1554 = ckks.add %ct_1553, %ct_1528 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1555 = ckks.add %ct_1531, %ct_1534 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1556 = ckks.add %ct_1555, %ct_1537 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1557 = ckks.add %ct_1554, %ct_1556 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1558 = ckks.add %ct_1552, %ct_1557 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1559 = ckks.add %ct_1547, %ct_1558 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1560 = ckks.rotate %ct_1559, %c368 : index : !ct_L5
    %pt_1561 = preprocessing.load %arg5[] site 391<!pt> : <!pt>, !pt
    %ct_1562 = ckks.mul_plain %extracted, %pt_1561 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1563 = ckks.rescale %ct_1562 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1564 = preprocessing.load %arg5[] site 392<!pt> : <!pt>, !pt
    %ct_1565 = ckks.mul_plain %ct_1, %pt_1564 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1566 = ckks.rescale %ct_1565 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1567 = preprocessing.load %arg5[] site 393<!pt> : <!pt>, !pt
    %ct_1568 = ckks.mul_plain %ct_5, %pt_1567 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1569 = ckks.rescale %ct_1568 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1570 = preprocessing.load %arg5[] site 394<!pt> : <!pt>, !pt
    %ct_1571 = ckks.mul_plain %ct_9, %pt_1570 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1572 = ckks.rescale %ct_1571 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1573 = preprocessing.load %arg5[] site 395<!pt> : <!pt>, !pt
    %ct_1574 = ckks.mul_plain %ct_13, %pt_1573 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1575 = ckks.rescale %ct_1574 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1576 = preprocessing.load %arg5[] site 396<!pt> : <!pt>, !pt
    %ct_1577 = ckks.mul_plain %ct_17, %pt_1576 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1578 = ckks.rescale %ct_1577 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1579 = preprocessing.load %arg5[] site 397<!pt> : <!pt>, !pt
    %ct_1580 = ckks.mul_plain %ct_21, %pt_1579 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1581 = ckks.rescale %ct_1580 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1582 = preprocessing.load %arg5[] site 398<!pt> : <!pt>, !pt
    %ct_1583 = ckks.mul_plain %ct_25, %pt_1582 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1584 = ckks.rescale %ct_1583 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1585 = preprocessing.load %arg5[] site 399<!pt> : <!pt>, !pt
    %ct_1586 = ckks.mul_plain %ct_29, %pt_1585 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1587 = ckks.rescale %ct_1586 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1588 = preprocessing.load %arg5[] site 400<!pt> : <!pt>, !pt
    %ct_1589 = ckks.mul_plain %ct_33, %pt_1588 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1590 = ckks.rescale %ct_1589 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1591 = preprocessing.load %arg5[] site 401<!pt> : <!pt>, !pt
    %ct_1592 = ckks.mul_plain %ct_37, %pt_1591 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1593 = ckks.rescale %ct_1592 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1594 = preprocessing.load %arg5[] site 402<!pt> : <!pt>, !pt
    %ct_1595 = ckks.mul_plain %ct_41, %pt_1594 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1596 = ckks.rescale %ct_1595 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1597 = preprocessing.load %arg5[] site 403<!pt> : <!pt>, !pt
    %ct_1598 = ckks.mul_plain %ct_45, %pt_1597 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1599 = ckks.rescale %ct_1598 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1600 = preprocessing.load %arg5[] site 404<!pt> : <!pt>, !pt
    %ct_1601 = ckks.mul_plain %ct_49, %pt_1600 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1602 = ckks.rescale %ct_1601 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1603 = preprocessing.load %arg5[] site 405<!pt> : <!pt>, !pt
    %ct_1604 = ckks.mul_plain %ct_53, %pt_1603 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1605 = ckks.rescale %ct_1604 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1606 = preprocessing.load %arg5[] site 406<!pt> : <!pt>, !pt
    %ct_1607 = ckks.mul_plain %ct_57, %pt_1606 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1608 = ckks.rescale %ct_1607 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1609 = preprocessing.load %arg5[] site 407<!pt> : <!pt>, !pt
    %ct_1610 = ckks.mul_plain %ct_61, %pt_1609 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1611 = ckks.rescale %ct_1610 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1612 = preprocessing.load %arg5[] site 408<!pt> : <!pt>, !pt
    %ct_1613 = ckks.mul_plain %ct_65, %pt_1612 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1614 = ckks.rescale %ct_1613 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1615 = preprocessing.load %arg5[] site 409<!pt> : <!pt>, !pt
    %ct_1616 = ckks.mul_plain %ct_69, %pt_1615 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1617 = ckks.rescale %ct_1616 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1618 = preprocessing.load %arg5[] site 410<!pt> : <!pt>, !pt
    %ct_1619 = ckks.mul_plain %ct_73, %pt_1618 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1620 = ckks.rescale %ct_1619 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1621 = preprocessing.load %arg5[] site 411<!pt> : <!pt>, !pt
    %ct_1622 = ckks.mul_plain %ct_77, %pt_1621 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1623 = ckks.rescale %ct_1622 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1624 = preprocessing.load %arg5[] site 412<!pt> : <!pt>, !pt
    %ct_1625 = ckks.mul_plain %ct_81, %pt_1624 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1626 = ckks.rescale %ct_1625 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1627 = preprocessing.load %arg5[] site 413<!pt> : <!pt>, !pt
    %ct_1628 = ckks.mul_plain %ct_85, %pt_1627 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1629 = ckks.rescale %ct_1628 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_1630 = ckks.add %ct_1563, %ct_1566 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1631 = ckks.add %ct_1569, %ct_1572 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1632 = ckks.add %ct_1631, %ct_1575 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1633 = ckks.add %ct_1630, %ct_1632 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1634 = ckks.add %ct_1578, %ct_1581 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1635 = ckks.add %ct_1634, %ct_1584 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1636 = ckks.add %ct_1587, %ct_1590 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1637 = ckks.add %ct_1636, %ct_1593 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1638 = ckks.add %ct_1635, %ct_1637 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1639 = ckks.add %ct_1633, %ct_1638 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1640 = ckks.add %ct_1596, %ct_1599 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1641 = ckks.add %ct_1640, %ct_1602 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1642 = ckks.add %ct_1605, %ct_1608 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1643 = ckks.add %ct_1642, %ct_1611 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1644 = ckks.add %ct_1641, %ct_1643 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1645 = ckks.add %ct_1614, %ct_1617 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1646 = ckks.add %ct_1645, %ct_1620 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1647 = ckks.add %ct_1623, %ct_1626 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1648 = ckks.add %ct_1647, %ct_1629 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1649 = ckks.add %ct_1646, %ct_1648 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1650 = ckks.add %ct_1644, %ct_1649 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1651 = ckks.add %ct_1639, %ct_1650 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1652 = ckks.rotate %ct_1651, %c391 : index : !ct_L5
    %pt_1653 = preprocessing.load %arg5[] site 414<!pt> : <!pt>, !pt
    %ct_1654 = ckks.mul_plain %extracted, %pt_1653 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1655 = ckks.rescale %ct_1654 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1656 = preprocessing.load %arg5[] site 415<!pt> : <!pt>, !pt
    %ct_1657 = ckks.mul_plain %ct_1, %pt_1656 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1658 = ckks.rescale %ct_1657 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1659 = preprocessing.load %arg5[] site 416<!pt> : <!pt>, !pt
    %ct_1660 = ckks.mul_plain %ct_5, %pt_1659 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1661 = ckks.rescale %ct_1660 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1662 = preprocessing.load %arg5[] site 417<!pt> : <!pt>, !pt
    %ct_1663 = ckks.mul_plain %ct_9, %pt_1662 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1664 = ckks.rescale %ct_1663 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1665 = preprocessing.load %arg5[] site 418<!pt> : <!pt>, !pt
    %ct_1666 = ckks.mul_plain %ct_13, %pt_1665 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1667 = ckks.rescale %ct_1666 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1668 = preprocessing.load %arg5[] site 419<!pt> : <!pt>, !pt
    %ct_1669 = ckks.mul_plain %ct_17, %pt_1668 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1670 = ckks.rescale %ct_1669 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1671 = preprocessing.load %arg5[] site 420<!pt> : <!pt>, !pt
    %ct_1672 = ckks.mul_plain %ct_21, %pt_1671 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1673 = ckks.rescale %ct_1672 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1674 = preprocessing.load %arg5[] site 421<!pt> : <!pt>, !pt
    %ct_1675 = ckks.mul_plain %ct_25, %pt_1674 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1676 = ckks.rescale %ct_1675 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1677 = preprocessing.load %arg5[] site 422<!pt> : <!pt>, !pt
    %ct_1678 = ckks.mul_plain %ct_29, %pt_1677 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1679 = ckks.rescale %ct_1678 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1680 = preprocessing.load %arg5[] site 423<!pt> : <!pt>, !pt
    %ct_1681 = ckks.mul_plain %ct_33, %pt_1680 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1682 = ckks.rescale %ct_1681 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1683 = preprocessing.load %arg5[] site 424<!pt> : <!pt>, !pt
    %ct_1684 = ckks.mul_plain %ct_37, %pt_1683 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1685 = ckks.rescale %ct_1684 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1686 = preprocessing.load %arg5[] site 425<!pt> : <!pt>, !pt
    %ct_1687 = ckks.mul_plain %ct_41, %pt_1686 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1688 = ckks.rescale %ct_1687 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1689 = preprocessing.load %arg5[] site 426<!pt> : <!pt>, !pt
    %ct_1690 = ckks.mul_plain %ct_45, %pt_1689 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1691 = ckks.rescale %ct_1690 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1692 = preprocessing.load %arg5[] site 427<!pt> : <!pt>, !pt
    %ct_1693 = ckks.mul_plain %ct_49, %pt_1692 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1694 = ckks.rescale %ct_1693 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1695 = preprocessing.load %arg5[] site 428<!pt> : <!pt>, !pt
    %ct_1696 = ckks.mul_plain %ct_53, %pt_1695 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1697 = ckks.rescale %ct_1696 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1698 = preprocessing.load %arg5[] site 429<!pt> : <!pt>, !pt
    %ct_1699 = ckks.mul_plain %ct_57, %pt_1698 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1700 = ckks.rescale %ct_1699 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1701 = preprocessing.load %arg5[] site 430<!pt> : <!pt>, !pt
    %ct_1702 = ckks.mul_plain %ct_61, %pt_1701 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1703 = ckks.rescale %ct_1702 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1704 = preprocessing.load %arg5[] site 431<!pt> : <!pt>, !pt
    %ct_1705 = ckks.mul_plain %ct_65, %pt_1704 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1706 = ckks.rescale %ct_1705 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1707 = preprocessing.load %arg5[] site 432<!pt> : <!pt>, !pt
    %ct_1708 = ckks.mul_plain %ct_69, %pt_1707 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1709 = ckks.rescale %ct_1708 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1710 = preprocessing.load %arg5[] site 433<!pt> : <!pt>, !pt
    %ct_1711 = ckks.mul_plain %ct_73, %pt_1710 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1712 = ckks.rescale %ct_1711 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1713 = preprocessing.load %arg5[] site 434<!pt> : <!pt>, !pt
    %ct_1714 = ckks.mul_plain %ct_77, %pt_1713 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1715 = ckks.rescale %ct_1714 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1716 = preprocessing.load %arg5[] site 435<!pt> : <!pt>, !pt
    %ct_1717 = ckks.mul_plain %ct_81, %pt_1716 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1718 = ckks.rescale %ct_1717 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1719 = preprocessing.load %arg5[] site 436<!pt> : <!pt>, !pt
    %ct_1720 = ckks.mul_plain %ct_85, %pt_1719 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1721 = ckks.rescale %ct_1720 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_1722 = ckks.add %ct_1655, %ct_1658 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1723 = ckks.add %ct_1661, %ct_1664 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1724 = ckks.add %ct_1723, %ct_1667 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1725 = ckks.add %ct_1722, %ct_1724 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1726 = ckks.add %ct_1670, %ct_1673 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1727 = ckks.add %ct_1726, %ct_1676 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1728 = ckks.add %ct_1679, %ct_1682 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1729 = ckks.add %ct_1728, %ct_1685 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1730 = ckks.add %ct_1727, %ct_1729 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1731 = ckks.add %ct_1725, %ct_1730 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1732 = ckks.add %ct_1688, %ct_1691 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1733 = ckks.add %ct_1732, %ct_1694 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1734 = ckks.add %ct_1697, %ct_1700 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1735 = ckks.add %ct_1734, %ct_1703 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1736 = ckks.add %ct_1733, %ct_1735 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1737 = ckks.add %ct_1706, %ct_1709 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1738 = ckks.add %ct_1737, %ct_1712 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1739 = ckks.add %ct_1715, %ct_1718 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1740 = ckks.add %ct_1739, %ct_1721 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1741 = ckks.add %ct_1738, %ct_1740 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1742 = ckks.add %ct_1736, %ct_1741 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1743 = ckks.add %ct_1731, %ct_1742 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1744 = ckks.rotate %ct_1743, %c414 : index : !ct_L5
    %pt_1745 = preprocessing.load %arg5[] site 437<!pt> : <!pt>, !pt
    %ct_1746 = ckks.mul_plain %extracted, %pt_1745 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1747 = ckks.rescale %ct_1746 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1748 = preprocessing.load %arg5[] site 438<!pt> : <!pt>, !pt
    %ct_1749 = ckks.mul_plain %ct_1, %pt_1748 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1750 = ckks.rescale %ct_1749 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1751 = preprocessing.load %arg5[] site 439<!pt> : <!pt>, !pt
    %ct_1752 = ckks.mul_plain %ct_5, %pt_1751 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1753 = ckks.rescale %ct_1752 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1754 = preprocessing.load %arg5[] site 440<!pt> : <!pt>, !pt
    %ct_1755 = ckks.mul_plain %ct_9, %pt_1754 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1756 = ckks.rescale %ct_1755 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1757 = preprocessing.load %arg5[] site 441<!pt> : <!pt>, !pt
    %ct_1758 = ckks.mul_plain %ct_13, %pt_1757 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1759 = ckks.rescale %ct_1758 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1760 = preprocessing.load %arg5[] site 442<!pt> : <!pt>, !pt
    %ct_1761 = ckks.mul_plain %ct_17, %pt_1760 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1762 = ckks.rescale %ct_1761 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1763 = preprocessing.load %arg5[] site 443<!pt> : <!pt>, !pt
    %ct_1764 = ckks.mul_plain %ct_21, %pt_1763 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1765 = ckks.rescale %ct_1764 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1766 = preprocessing.load %arg5[] site 444<!pt> : <!pt>, !pt
    %ct_1767 = ckks.mul_plain %ct_25, %pt_1766 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1768 = ckks.rescale %ct_1767 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1769 = preprocessing.load %arg5[] site 445<!pt> : <!pt>, !pt
    %ct_1770 = ckks.mul_plain %ct_29, %pt_1769 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1771 = ckks.rescale %ct_1770 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1772 = preprocessing.load %arg5[] site 446<!pt> : <!pt>, !pt
    %ct_1773 = ckks.mul_plain %ct_33, %pt_1772 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1774 = ckks.rescale %ct_1773 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1775 = preprocessing.load %arg5[] site 447<!pt> : <!pt>, !pt
    %ct_1776 = ckks.mul_plain %ct_37, %pt_1775 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1777 = ckks.rescale %ct_1776 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1778 = preprocessing.load %arg5[] site 448<!pt> : <!pt>, !pt
    %ct_1779 = ckks.mul_plain %ct_41, %pt_1778 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1780 = ckks.rescale %ct_1779 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1781 = preprocessing.load %arg5[] site 449<!pt> : <!pt>, !pt
    %ct_1782 = ckks.mul_plain %ct_45, %pt_1781 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1783 = ckks.rescale %ct_1782 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1784 = preprocessing.load %arg5[] site 450<!pt> : <!pt>, !pt
    %ct_1785 = ckks.mul_plain %ct_49, %pt_1784 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1786 = ckks.rescale %ct_1785 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1787 = preprocessing.load %arg5[] site 451<!pt> : <!pt>, !pt
    %ct_1788 = ckks.mul_plain %ct_53, %pt_1787 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1789 = ckks.rescale %ct_1788 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1790 = preprocessing.load %arg5[] site 452<!pt> : <!pt>, !pt
    %ct_1791 = ckks.mul_plain %ct_57, %pt_1790 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1792 = ckks.rescale %ct_1791 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1793 = preprocessing.load %arg5[] site 453<!pt> : <!pt>, !pt
    %ct_1794 = ckks.mul_plain %ct_61, %pt_1793 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1795 = ckks.rescale %ct_1794 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1796 = preprocessing.load %arg5[] site 454<!pt> : <!pt>, !pt
    %ct_1797 = ckks.mul_plain %ct_65, %pt_1796 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1798 = ckks.rescale %ct_1797 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1799 = preprocessing.load %arg5[] site 455<!pt> : <!pt>, !pt
    %ct_1800 = ckks.mul_plain %ct_69, %pt_1799 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1801 = ckks.rescale %ct_1800 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1802 = preprocessing.load %arg5[] site 456<!pt> : <!pt>, !pt
    %ct_1803 = ckks.mul_plain %ct_73, %pt_1802 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1804 = ckks.rescale %ct_1803 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1805 = preprocessing.load %arg5[] site 457<!pt> : <!pt>, !pt
    %ct_1806 = ckks.mul_plain %ct_77, %pt_1805 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1807 = ckks.rescale %ct_1806 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1808 = preprocessing.load %arg5[] site 458<!pt> : <!pt>, !pt
    %ct_1809 = ckks.mul_plain %ct_81, %pt_1808 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1810 = ckks.rescale %ct_1809 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1811 = preprocessing.load %arg5[] site 459<!pt> : <!pt>, !pt
    %ct_1812 = ckks.mul_plain %ct_85, %pt_1811 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1813 = ckks.rescale %ct_1812 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_1814 = ckks.add %ct_1747, %ct_1750 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1815 = ckks.add %ct_1753, %ct_1756 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1816 = ckks.add %ct_1815, %ct_1759 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1817 = ckks.add %ct_1814, %ct_1816 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1818 = ckks.add %ct_1762, %ct_1765 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1819 = ckks.add %ct_1818, %ct_1768 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1820 = ckks.add %ct_1771, %ct_1774 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1821 = ckks.add %ct_1820, %ct_1777 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1822 = ckks.add %ct_1819, %ct_1821 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1823 = ckks.add %ct_1817, %ct_1822 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1824 = ckks.add %ct_1780, %ct_1783 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1825 = ckks.add %ct_1824, %ct_1786 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1826 = ckks.add %ct_1789, %ct_1792 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1827 = ckks.add %ct_1826, %ct_1795 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1828 = ckks.add %ct_1825, %ct_1827 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1829 = ckks.add %ct_1798, %ct_1801 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1830 = ckks.add %ct_1829, %ct_1804 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1831 = ckks.add %ct_1807, %ct_1810 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1832 = ckks.add %ct_1831, %ct_1813 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1833 = ckks.add %ct_1830, %ct_1832 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1834 = ckks.add %ct_1828, %ct_1833 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1835 = ckks.add %ct_1823, %ct_1834 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1836 = ckks.rotate %ct_1835, %c437 : index : !ct_L5
    %pt_1837 = preprocessing.load %arg5[] site 460<!pt> : <!pt>, !pt
    %ct_1838 = ckks.mul_plain %extracted, %pt_1837 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1839 = ckks.rescale %ct_1838 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1840 = preprocessing.load %arg5[] site 461<!pt> : <!pt>, !pt
    %ct_1841 = ckks.mul_plain %ct_1, %pt_1840 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1842 = ckks.rescale %ct_1841 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1843 = preprocessing.load %arg5[] site 462<!pt> : <!pt>, !pt
    %ct_1844 = ckks.mul_plain %ct_5, %pt_1843 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1845 = ckks.rescale %ct_1844 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1846 = preprocessing.load %arg5[] site 463<!pt> : <!pt>, !pt
    %ct_1847 = ckks.mul_plain %ct_9, %pt_1846 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1848 = ckks.rescale %ct_1847 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1849 = preprocessing.load %arg5[] site 464<!pt> : <!pt>, !pt
    %ct_1850 = ckks.mul_plain %ct_13, %pt_1849 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1851 = ckks.rescale %ct_1850 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1852 = preprocessing.load %arg5[] site 465<!pt> : <!pt>, !pt
    %ct_1853 = ckks.mul_plain %ct_17, %pt_1852 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1854 = ckks.rescale %ct_1853 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1855 = preprocessing.load %arg5[] site 466<!pt> : <!pt>, !pt
    %ct_1856 = ckks.mul_plain %ct_21, %pt_1855 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1857 = ckks.rescale %ct_1856 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1858 = preprocessing.load %arg5[] site 467<!pt> : <!pt>, !pt
    %ct_1859 = ckks.mul_plain %ct_25, %pt_1858 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1860 = ckks.rescale %ct_1859 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1861 = preprocessing.load %arg5[] site 468<!pt> : <!pt>, !pt
    %ct_1862 = ckks.mul_plain %ct_29, %pt_1861 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1863 = ckks.rescale %ct_1862 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1864 = preprocessing.load %arg5[] site 469<!pt> : <!pt>, !pt
    %ct_1865 = ckks.mul_plain %ct_33, %pt_1864 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1866 = ckks.rescale %ct_1865 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1867 = preprocessing.load %arg5[] site 470<!pt> : <!pt>, !pt
    %ct_1868 = ckks.mul_plain %ct_37, %pt_1867 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1869 = ckks.rescale %ct_1868 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1870 = preprocessing.load %arg5[] site 471<!pt> : <!pt>, !pt
    %ct_1871 = ckks.mul_plain %ct_41, %pt_1870 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1872 = ckks.rescale %ct_1871 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1873 = preprocessing.load %arg5[] site 472<!pt> : <!pt>, !pt
    %ct_1874 = ckks.mul_plain %ct_45, %pt_1873 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1875 = ckks.rescale %ct_1874 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1876 = preprocessing.load %arg5[] site 473<!pt> : <!pt>, !pt
    %ct_1877 = ckks.mul_plain %ct_49, %pt_1876 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1878 = ckks.rescale %ct_1877 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1879 = preprocessing.load %arg5[] site 474<!pt> : <!pt>, !pt
    %ct_1880 = ckks.mul_plain %ct_53, %pt_1879 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1881 = ckks.rescale %ct_1880 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1882 = preprocessing.load %arg5[] site 475<!pt> : <!pt>, !pt
    %ct_1883 = ckks.mul_plain %ct_57, %pt_1882 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1884 = ckks.rescale %ct_1883 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1885 = preprocessing.load %arg5[] site 476<!pt> : <!pt>, !pt
    %ct_1886 = ckks.mul_plain %ct_61, %pt_1885 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1887 = ckks.rescale %ct_1886 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1888 = preprocessing.load %arg5[] site 477<!pt> : <!pt>, !pt
    %ct_1889 = ckks.mul_plain %ct_65, %pt_1888 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1890 = ckks.rescale %ct_1889 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1891 = preprocessing.load %arg5[] site 478<!pt> : <!pt>, !pt
    %ct_1892 = ckks.mul_plain %ct_69, %pt_1891 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1893 = ckks.rescale %ct_1892 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1894 = preprocessing.load %arg5[] site 479<!pt> : <!pt>, !pt
    %ct_1895 = ckks.mul_plain %ct_73, %pt_1894 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1896 = ckks.rescale %ct_1895 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1897 = preprocessing.load %arg5[] site 480<!pt> : <!pt>, !pt
    %ct_1898 = ckks.mul_plain %ct_77, %pt_1897 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1899 = ckks.rescale %ct_1898 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1900 = preprocessing.load %arg5[] site 481<!pt> : <!pt>, !pt
    %ct_1901 = ckks.mul_plain %ct_81, %pt_1900 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1902 = ckks.rescale %ct_1901 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1903 = preprocessing.load %arg5[] site 482<!pt> : <!pt>, !pt
    %ct_1904 = ckks.mul_plain %ct_85, %pt_1903 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1905 = ckks.rescale %ct_1904 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_1906 = ckks.add %ct_1839, %ct_1842 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1907 = ckks.add %ct_1845, %ct_1848 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1908 = ckks.add %ct_1907, %ct_1851 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1909 = ckks.add %ct_1906, %ct_1908 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1910 = ckks.add %ct_1854, %ct_1857 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1911 = ckks.add %ct_1910, %ct_1860 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1912 = ckks.add %ct_1863, %ct_1866 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1913 = ckks.add %ct_1912, %ct_1869 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1914 = ckks.add %ct_1911, %ct_1913 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1915 = ckks.add %ct_1909, %ct_1914 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1916 = ckks.add %ct_1872, %ct_1875 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1917 = ckks.add %ct_1916, %ct_1878 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1918 = ckks.add %ct_1881, %ct_1884 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1919 = ckks.add %ct_1918, %ct_1887 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1920 = ckks.add %ct_1917, %ct_1919 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1921 = ckks.add %ct_1890, %ct_1893 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1922 = ckks.add %ct_1921, %ct_1896 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1923 = ckks.add %ct_1899, %ct_1902 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1924 = ckks.add %ct_1923, %ct_1905 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1925 = ckks.add %ct_1922, %ct_1924 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1926 = ckks.add %ct_1920, %ct_1925 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1927 = ckks.add %ct_1915, %ct_1926 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1928 = ckks.rotate %ct_1927, %c460 : index : !ct_L5
    %pt_1929 = preprocessing.load %arg5[] site 483<!pt> : <!pt>, !pt
    %ct_1930 = ckks.mul_plain %extracted, %pt_1929 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1931 = ckks.rescale %ct_1930 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1932 = preprocessing.load %arg5[] site 484<!pt> : <!pt>, !pt
    %ct_1933 = ckks.mul_plain %ct_1, %pt_1932 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1934 = ckks.rescale %ct_1933 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1935 = preprocessing.load %arg5[] site 485<!pt> : <!pt>, !pt
    %ct_1936 = ckks.mul_plain %ct_5, %pt_1935 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1937 = ckks.rescale %ct_1936 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1938 = preprocessing.load %arg5[] site 486<!pt> : <!pt>, !pt
    %ct_1939 = ckks.mul_plain %ct_9, %pt_1938 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1940 = ckks.rescale %ct_1939 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1941 = preprocessing.load %arg5[] site 487<!pt> : <!pt>, !pt
    %ct_1942 = ckks.mul_plain %ct_13, %pt_1941 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1943 = ckks.rescale %ct_1942 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1944 = preprocessing.load %arg5[] site 488<!pt> : <!pt>, !pt
    %ct_1945 = ckks.mul_plain %ct_17, %pt_1944 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1946 = ckks.rescale %ct_1945 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1947 = preprocessing.load %arg5[] site 489<!pt> : <!pt>, !pt
    %ct_1948 = ckks.mul_plain %ct_21, %pt_1947 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1949 = ckks.rescale %ct_1948 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1950 = preprocessing.load %arg5[] site 490<!pt> : <!pt>, !pt
    %ct_1951 = ckks.mul_plain %ct_25, %pt_1950 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1952 = ckks.rescale %ct_1951 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1953 = preprocessing.load %arg5[] site 491<!pt> : <!pt>, !pt
    %ct_1954 = ckks.mul_plain %ct_29, %pt_1953 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1955 = ckks.rescale %ct_1954 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1956 = preprocessing.load %arg5[] site 492<!pt> : <!pt>, !pt
    %ct_1957 = ckks.mul_plain %ct_33, %pt_1956 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1958 = ckks.rescale %ct_1957 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1959 = preprocessing.load %arg5[] site 493<!pt> : <!pt>, !pt
    %ct_1960 = ckks.mul_plain %ct_37, %pt_1959 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1961 = ckks.rescale %ct_1960 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1962 = preprocessing.load %arg5[] site 494<!pt> : <!pt>, !pt
    %ct_1963 = ckks.mul_plain %ct_41, %pt_1962 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1964 = ckks.rescale %ct_1963 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1965 = preprocessing.load %arg5[] site 495<!pt> : <!pt>, !pt
    %ct_1966 = ckks.mul_plain %ct_45, %pt_1965 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1967 = ckks.rescale %ct_1966 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1968 = preprocessing.load %arg5[] site 496<!pt> : <!pt>, !pt
    %ct_1969 = ckks.mul_plain %ct_49, %pt_1968 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1970 = ckks.rescale %ct_1969 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1971 = preprocessing.load %arg5[] site 497<!pt> : <!pt>, !pt
    %ct_1972 = ckks.mul_plain %ct_53, %pt_1971 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1973 = ckks.rescale %ct_1972 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1974 = preprocessing.load %arg5[] site 498<!pt> : <!pt>, !pt
    %ct_1975 = ckks.mul_plain %ct_57, %pt_1974 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1976 = ckks.rescale %ct_1975 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1977 = preprocessing.load %arg5[] site 499<!pt> : <!pt>, !pt
    %ct_1978 = ckks.mul_plain %ct_61, %pt_1977 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1979 = ckks.rescale %ct_1978 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1980 = preprocessing.load %arg5[] site 500<!pt> : <!pt>, !pt
    %ct_1981 = ckks.mul_plain %ct_65, %pt_1980 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1982 = ckks.rescale %ct_1981 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1983 = preprocessing.load %arg5[] site 501<!pt> : <!pt>, !pt
    %ct_1984 = ckks.mul_plain %ct_69, %pt_1983 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1985 = ckks.rescale %ct_1984 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1986 = preprocessing.load %arg5[] site 502<!pt> : <!pt>, !pt
    %ct_1987 = ckks.mul_plain %ct_73, %pt_1986 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1988 = ckks.rescale %ct_1987 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1989 = preprocessing.load %arg5[] site 503<!pt> : <!pt>, !pt
    %ct_1990 = ckks.mul_plain %ct_77, %pt_1989 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1991 = ckks.rescale %ct_1990 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1992 = preprocessing.load %arg5[] site 504<!pt> : <!pt>, !pt
    %ct_1993 = ckks.mul_plain %ct_81, %pt_1992 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1994 = ckks.rescale %ct_1993 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_1995 = preprocessing.load %arg5[] site 505<!pt> : <!pt>, !pt
    %ct_1996 = ckks.mul_plain %ct_85, %pt_1995 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_1997 = ckks.rescale %ct_1996 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_1998 = ckks.add %ct_1931, %ct_1934 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_1999 = ckks.add %ct_1937, %ct_1940 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2000 = ckks.add %ct_1999, %ct_1943 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2001 = ckks.add %ct_1998, %ct_2000 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2002 = ckks.add %ct_1946, %ct_1949 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2003 = ckks.add %ct_2002, %ct_1952 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2004 = ckks.add %ct_1955, %ct_1958 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2005 = ckks.add %ct_2004, %ct_1961 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2006 = ckks.add %ct_2003, %ct_2005 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2007 = ckks.add %ct_2001, %ct_2006 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2008 = ckks.add %ct_1964, %ct_1967 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2009 = ckks.add %ct_2008, %ct_1970 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2010 = ckks.add %ct_1973, %ct_1976 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2011 = ckks.add %ct_2010, %ct_1979 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2012 = ckks.add %ct_2009, %ct_2011 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2013 = ckks.add %ct_1982, %ct_1985 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2014 = ckks.add %ct_2013, %ct_1988 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2015 = ckks.add %ct_1991, %ct_1994 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2016 = ckks.add %ct_2015, %ct_1997 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2017 = ckks.add %ct_2014, %ct_2016 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2018 = ckks.add %ct_2012, %ct_2017 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2019 = ckks.add %ct_2007, %ct_2018 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2020 = ckks.rotate %ct_2019, %c483 : index : !ct_L5
    %pt_2021 = preprocessing.load %arg5[] site 506<!pt> : <!pt>, !pt
    %ct_2022 = ckks.mul_plain %extracted, %pt_2021 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_2023 = ckks.rescale %ct_2022 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_2024 = preprocessing.load %arg5[] site 507<!pt> : <!pt>, !pt
    %ct_2025 = ckks.mul_plain %ct_1, %pt_2024 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_2026 = ckks.rescale %ct_2025 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_2027 = preprocessing.load %arg5[] site 508<!pt> : <!pt>, !pt
    %ct_2028 = ckks.mul_plain %ct_5, %pt_2027 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_2029 = ckks.rescale %ct_2028 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_2030 = preprocessing.load %arg5[] site 509<!pt> : <!pt>, !pt
    %ct_2031 = ckks.mul_plain %ct_9, %pt_2030 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_2032 = ckks.rescale %ct_2031 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_2033 = preprocessing.load %arg5[] site 510<!pt> : <!pt>, !pt
    %ct_2034 = ckks.mul_plain %ct_13, %pt_2033 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_2035 = ckks.rescale %ct_2034 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %pt_2036 = preprocessing.load %arg5[] site 511<!pt> : <!pt>, !pt
    %ct_2037 = ckks.mul_plain %ct_17, %pt_2036 : (!ct_L6, !pt) -> !ct_L6_1
    %ct_2038 = ckks.rescale %ct_2037 <to_ring = #ring_rns_L5_1_x32768> : !ct_L6_1 -> !ct_L5
    %ct_2039 = ckks.add %ct_2023, %ct_2026 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2040 = ckks.add %ct_2039, %ct_2029 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2041 = ckks.add %ct_2032, %ct_2035 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2042 = ckks.add %ct_2041, %ct_2038 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2043 = ckks.add %ct_2040, %ct_2042 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2044 = ckks.rotate %ct_2043, %c506 : index : !ct_L5
    %ct_2045 = ckks.add %ct_0, %ct_4 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2046 = ckks.add %ct_8, %ct_12 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2047 = ckks.add %ct_2046, %ct_16 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2048 = ckks.add %ct_2045, %ct_2047 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2049 = ckks.add %ct_20, %ct_24 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2050 = ckks.add %ct_2049, %ct_28 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2051 = ckks.add %ct_32, %ct_36 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2052 = ckks.add %ct_2051, %ct_40 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2053 = ckks.add %ct_2050, %ct_2052 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2054 = ckks.add %ct_2048, %ct_2053 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2055 = ckks.add %ct_44, %ct_48 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2056 = ckks.add %ct_52, %ct_56 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2057 = ckks.add %ct_2056, %ct_60 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2058 = ckks.add %ct_2055, %ct_2057 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2059 = ckks.add %ct_64, %ct_68 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2060 = ckks.add %ct_2059, %ct_72 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2061 = ckks.add %ct_76, %ct_80 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2062 = ckks.add %ct_2061, %ct_84 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2063 = ckks.add %ct_2060, %ct_2062 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2064 = ckks.add %ct_2058, %ct_2063 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2065 = ckks.add %ct_2054, %ct_2064 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2066 = ckks.add %ct_88, %ct_180 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2067 = ckks.add %ct_272, %ct_364 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2068 = ckks.add %ct_2067, %ct_456 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2069 = ckks.add %ct_2066, %ct_2068 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2070 = ckks.add %ct_548, %ct_640 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2071 = ckks.add %ct_2070, %ct_732 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2072 = ckks.add %ct_824, %ct_916 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2073 = ckks.add %ct_2072, %ct_1008 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2074 = ckks.add %ct_2071, %ct_2073 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2075 = ckks.add %ct_2069, %ct_2074 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2076 = ckks.add %ct_1100, %ct_1192 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2077 = ckks.add %ct_2076, %ct_1284 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2078 = ckks.add %ct_1376, %ct_1468 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2079 = ckks.add %ct_2078, %ct_1560 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2080 = ckks.add %ct_2077, %ct_2079 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2081 = ckks.add %ct_1652, %ct_1744 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2082 = ckks.add %ct_2081, %ct_1836 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2083 = ckks.add %ct_1928, %ct_2020 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2084 = ckks.add %ct_2083, %ct_2044 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2085 = ckks.add %ct_2082, %ct_2084 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2086 = ckks.add %ct_2080, %ct_2085 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2087 = ckks.add %ct_2075, %ct_2086 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2088 = ckks.add %ct_2065, %ct_2087 : (!ct_L5, !ct_L5) -> !ct_L5
    %ct_2089 = ckks.rotate %ct_2088, %c512 : index : !ct_L5
    %pt_2090 = preprocessing.load %arg5[] site 512<!pt> : <!pt>, !pt
    %ct_2091 = ckks.add_plain %ct_2088, %pt_2090 : (!ct_L5, !pt) -> !ct_L5
    %ct_2092 = ckks.add %ct_2091, %ct_2089 : (!ct_L5, !ct_L5) -> !ct_L5
    %pt_2093 = preprocessing.load %arg5[] site 513<!pt> : <!pt>, !pt
    %ct_2094 = ckks.mul_plain %ct_2092, %pt_2093 {heir.kernel_info = {gap_factor = 1 : i64, result_shape = array<i64: 1, 512>}} : (!ct_L5, !pt) -> !ct_L5_1
    %ct_2095 = ckks.rescale %ct_2094 <to_ring = #ring_rns_L4_1_x32768> : !ct_L5_1 -> !ct_L4
    %ct_2096 = kernel.eval_chebyshev %ct_2095 <coefficients = [6.3393991028159498, 1.000000e+01, 4.3075053667521672, -8.1728713370568291E-16, -1.2656936164678267, -5.7991334850882538E-16]> {heir.kernel_info = {gap_factor = 1 : i64, result_shape = array<i64: 1, 512>}} : !ct_L4 -> !ct_L1
    %pt_2097 = preprocessing.load %arg5[] site 514<!pt> : <!pt>, !pt
    %ct_2098 = ckks.mul_plain %ct_2096, %pt_2097 : (!ct_L1, !pt) -> !ct_L1_1
    %ct_2099 = ckks.rescale %ct_2098 <to_ring = #ring_rns_L0_1_x32768> : !ct_L1_1 -> !ct_L0
    %ct_2100 = ckks.rotate %ct_2096, %c1 : index : !ct_L1
    %pt_2101 = preprocessing.load %arg5[] site 515<!pt> : <!pt>, !pt
    %ct_2102 = ckks.mul_plain %ct_2100, %pt_2101 : (!ct_L1, !pt) -> !ct_L1_1
    %ct_2103 = ckks.rescale %ct_2102 <to_ring = #ring_rns_L0_1_x32768> : !ct_L1_1 -> !ct_L0
    %ct_2104 = ckks.rotate %ct_2096, %c2 : index : !ct_L1
    %pt_2105 = preprocessing.load %arg5[] site 516<!pt> : <!pt>, !pt
    %ct_2106 = ckks.mul_plain %ct_2104, %pt_2105 : (!ct_L1, !pt) -> !ct_L1_1
    %ct_2107 = ckks.rescale %ct_2106 <to_ring = #ring_rns_L0_1_x32768> : !ct_L1_1 -> !ct_L0
    %ct_2108 = ckks.rotate %ct_2096, %c3 : index : !ct_L1
    %pt_2109 = preprocessing.load %arg5[] site 517<!pt> : <!pt>, !pt
    %ct_2110 = ckks.mul_plain %ct_2108, %pt_2109 : (!ct_L1, !pt) -> !ct_L1_1
    %ct_2111 = ckks.rescale %ct_2110 <to_ring = #ring_rns_L0_1_x32768> : !ct_L1_1 -> !ct_L0
    %pt_2112 = preprocessing.load %arg5[] site 518<!pt> : <!pt>, !pt
    %ct_2113 = ckks.mul_plain %ct_2096, %pt_2112 : (!ct_L1, !pt) -> !ct_L1_1
    %ct_2114 = ckks.rescale %ct_2113 <to_ring = #ring_rns_L0_1_x32768> : !ct_L1_1 -> !ct_L0
    %pt_2115 = preprocessing.load %arg5[] site 519<!pt> : <!pt>, !pt
    %ct_2116 = ckks.mul_plain %ct_2100, %pt_2115 : (!ct_L1, !pt) -> !ct_L1_1
    %ct_2117 = ckks.rescale %ct_2116 <to_ring = #ring_rns_L0_1_x32768> : !ct_L1_1 -> !ct_L0
    %pt_2118 = preprocessing.load %arg5[] site 520<!pt> : <!pt>, !pt
    %ct_2119 = ckks.mul_plain %ct_2104, %pt_2118 : (!ct_L1, !pt) -> !ct_L1_1
    %ct_2120 = ckks.rescale %ct_2119 <to_ring = #ring_rns_L0_1_x32768> : !ct_L1_1 -> !ct_L0
    %pt_2121 = preprocessing.load %arg5[] site 521<!pt> : <!pt>, !pt
    %ct_2122 = ckks.mul_plain %ct_2108, %pt_2121 : (!ct_L1, !pt) -> !ct_L1_1
    %ct_2123 = ckks.rescale %ct_2122 <to_ring = #ring_rns_L0_1_x32768> : !ct_L1_1 -> !ct_L0
    %ct_2124 = ckks.add %ct_2114, %ct_2117 : (!ct_L0, !ct_L0) -> !ct_L0
    %ct_2125 = ckks.add %ct_2120, %ct_2123 : (!ct_L0, !ct_L0) -> !ct_L0
    %ct_2126 = ckks.add %ct_2124, %ct_2125 : (!ct_L0, !ct_L0) -> !ct_L0
    %ct_2127 = ckks.rotate %ct_2126, %c4 : index : !ct_L0
    %pt_2128 = preprocessing.load %arg5[] site 522<!pt> : <!pt>, !pt
    %ct_2129 = ckks.mul_plain %ct_2096, %pt_2128 : (!ct_L1, !pt) -> !ct_L1_1
    %ct_2130 = ckks.rescale %ct_2129 <to_ring = #ring_rns_L0_1_x32768> : !ct_L1_1 -> !ct_L0
    %pt_2131 = preprocessing.load %arg5[] site 523<!pt> : <!pt>, !pt
    %ct_2132 = ckks.mul_plain %ct_2100, %pt_2131 : (!ct_L1, !pt) -> !ct_L1_1
    %ct_2133 = ckks.rescale %ct_2132 <to_ring = #ring_rns_L0_1_x32768> : !ct_L1_1 -> !ct_L0
    %pt_2134 = preprocessing.load %arg5[] site 524<!pt> : <!pt>, !pt
    %ct_2135 = ckks.mul_plain %ct_2104, %pt_2134 : (!ct_L1, !pt) -> !ct_L1_1
    %ct_2136 = ckks.rescale %ct_2135 <to_ring = #ring_rns_L0_1_x32768> : !ct_L1_1 -> !ct_L0
    %pt_2137 = preprocessing.load %arg5[] site 525<!pt> : <!pt>, !pt
    %ct_2138 = ckks.mul_plain %ct_2108, %pt_2137 : (!ct_L1, !pt) -> !ct_L1_1
    %ct_2139 = ckks.rescale %ct_2138 <to_ring = #ring_rns_L0_1_x32768> : !ct_L1_1 -> !ct_L0
    %ct_2140 = ckks.add %ct_2130, %ct_2133 : (!ct_L0, !ct_L0) -> !ct_L0
    %ct_2141 = ckks.add %ct_2136, %ct_2139 : (!ct_L0, !ct_L0) -> !ct_L0
    %ct_2142 = ckks.add %ct_2140, %ct_2141 : (!ct_L0, !ct_L0) -> !ct_L0
    %ct_2143 = ckks.rotate %ct_2142, %c8 : index : !ct_L0
    %pt_2144 = preprocessing.load %arg5[] site 526<!pt> : <!pt>, !pt
    %ct_2145 = ckks.mul_plain %ct_2096, %pt_2144 : (!ct_L1, !pt) -> !ct_L1_1
    %ct_2146 = ckks.rescale %ct_2145 <to_ring = #ring_rns_L0_1_x32768> : !ct_L1_1 -> !ct_L0
    %pt_2147 = preprocessing.load %arg5[] site 527<!pt> : <!pt>, !pt
    %ct_2148 = ckks.mul_plain %ct_2100, %pt_2147 : (!ct_L1, !pt) -> !ct_L1_1
    %ct_2149 = ckks.rescale %ct_2148 <to_ring = #ring_rns_L0_1_x32768> : !ct_L1_1 -> !ct_L0
    %pt_2150 = preprocessing.load %arg5[] site 528<!pt> : <!pt>, !pt
    %ct_2151 = ckks.mul_plain %ct_2104, %pt_2150 : (!ct_L1, !pt) -> !ct_L1_1
    %ct_2152 = ckks.rescale %ct_2151 <to_ring = #ring_rns_L0_1_x32768> : !ct_L1_1 -> !ct_L0
    %pt_2153 = preprocessing.load %arg5[] site 529<!pt> : <!pt>, !pt
    %ct_2154 = ckks.mul_plain %ct_2108, %pt_2153 : (!ct_L1, !pt) -> !ct_L1_1
    %ct_2155 = ckks.rescale %ct_2154 <to_ring = #ring_rns_L0_1_x32768> : !ct_L1_1 -> !ct_L0
    %ct_2156 = ckks.add %ct_2146, %ct_2149 : (!ct_L0, !ct_L0) -> !ct_L0
    %ct_2157 = ckks.add %ct_2152, %ct_2155 : (!ct_L0, !ct_L0) -> !ct_L0
    %ct_2158 = ckks.add %ct_2156, %ct_2157 : (!ct_L0, !ct_L0) -> !ct_L0
    %ct_2159 = ckks.rotate %ct_2158, %c12 : index : !ct_L0
    %ct_2160 = ckks.add %ct_2099, %ct_2103 : (!ct_L0, !ct_L0) -> !ct_L0
    %ct_2161 = ckks.add %ct_2160, %ct_2107 : (!ct_L0, !ct_L0) -> !ct_L0
    %ct_2162 = ckks.add %ct_2111, %ct_2127 : (!ct_L0, !ct_L0) -> !ct_L0
    %ct_2163 = ckks.add %ct_2143, %ct_2159 : (!ct_L0, !ct_L0) -> !ct_L0
    %ct_2164 = ckks.add %ct_2162, %ct_2163 : (!ct_L0, !ct_L0) -> !ct_L0
    %ct_2165 = ckks.add %ct_2161, %ct_2164 : (!ct_L0, !ct_L0) -> !ct_L0
    %ct_2166 = ckks.rotate %ct_2165, %c256 : index : !ct_L0
    %ct_2167 = ckks.add %ct_2165, %ct_2166 : (!ct_L0, !ct_L0) -> !ct_L0
    %ct_2168 = ckks.rotate %ct_2167, %c128 : index : !ct_L0
    %ct_2169 = ckks.add %ct_2167, %ct_2168 : (!ct_L0, !ct_L0) -> !ct_L0
    %ct_2170 = ckks.rotate %ct_2169, %c64 : index : !ct_L0
    %ct_2171 = ckks.add %ct_2169, %ct_2170 : (!ct_L0, !ct_L0) -> !ct_L0
    %ct_2172 = ckks.rotate %ct_2171, %c32 : index : !ct_L0
    %ct_2173 = ckks.add %ct_2171, %ct_2172 : (!ct_L0, !ct_L0) -> !ct_L0
    %ct_2174 = ckks.rotate %ct_2173, %c16 : index : !ct_L0
    %pt_2175 = preprocessing.load %arg5[] site 530<!pt> : <!pt>, !pt
    %ct_2176 = ckks.add_plain %ct_2173, %pt_2175 : (!ct_L0, !pt) -> !ct_L0
    %4 = tensor.empty() : tensor<1x!ct_L0>
    %ct_2177 = ckks.add %ct_2176, %ct_2174 : (!ct_L0, !ct_L0) -> !ct_L0
    %inserted = tensor.insert %ct_2177 into %4[%c0] : tensor<1x!ct_L0>
    return %inserted : tensor<1x!ct_L0>
  }
}
